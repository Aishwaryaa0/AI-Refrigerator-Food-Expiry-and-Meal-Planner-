"""
Meal Planner Module
Handles meal planning, recipe management, and nutrition tracking
"""

import sqlite3
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class MealType(Enum):
    BREAKFAST = "breakfast"
    LUNCH = "lunch"
    DINNER = "dinner"
    SNACK = "snack"


@dataclass
class Recipe:
    id: int
    name: str
    description: str
    ingredients: List[str]
    instructions: List[str]
    prep_time: int
    cook_time: int
    servings: int
    calories: int
    protein: float
    carbs: float
    fat: float
    tags: List[str]


@dataclass
class MealPlan:
    id: int
    date: datetime
    meal_type: MealType
    recipe: Recipe
    servings: int
    notes: str = ""


class RecipeDatabase:
    """Database of recipes with nutritional information"""
    
    RECIPES = {
        'scrambled_eggs': {
            'name': 'Scrambled Eggs',
            'description': 'Fluffy scrambled eggs',
            'ingredients': ['eggs', 'butter', 'salt', 'pepper', 'milk'],
            'instructions': ['Beat eggs with milk', 'Melt butter in pan', 
                           'Pour eggs and stir gently', 'Season and serve'],
            'prep_time': 5, 'cook_time': 5, 'servings': 2,
            'calories': 220, 'protein': 14, 'carbs': 2, 'fat': 18,
            'tags': ['breakfast', 'quick', 'high-protein']
        },
        'chicken_salad': {
            'name': 'Chicken Salad',
            'description': 'Fresh salad with grilled chicken',
            'ingredients': ['chicken breast', 'lettuce', 'tomatoes', 
                          'cucumber', 'olive oil', 'lemon'],
            'instructions': ['Grill chicken', 'Chop vegetables', 
                           'Slice chicken', 'Mix and dress'],
            'prep_time': 15, 'cook_time': 15, 'servings': 2,
            'calories': 350, 'protein': 35, 'carbs': 10, 'fat': 18,
            'tags': ['lunch', 'healthy', 'high-protein']
        },
        'grilled_chicken': {
            'name': 'Grilled Chicken with Rice',
            'description': 'Classic grilled chicken dinner',
            'ingredients': ['chicken breast', 'rice', 'vegetables', 
                          'garlic', 'olive oil', 'herbs'],
            'instructions': ['Marinate chicken', 'Cook rice', 
                           'Grill chicken', 'Steam vegetables', 'Serve together'],
            'prep_time': 20, 'cook_time': 30, 'servings': 2,
            'calories': 520, 'protein': 42, 'carbs': 45, 'fat': 15,
            'tags': ['dinner', 'high-protein', 'balanced']
        },
        'vegetable_stir_fry': {
            'name': 'Vegetable Stir Fry',
            'description': 'Quick and healthy vegetable stir fry',
            'ingredients': ['mixed vegetables', 'soy sauce', 'garlic', 
                          'ginger', 'sesame oil', 'rice'],
            'instructions': ['Chop vegetables', 'Heat oil', 
                           'Stir fry vegetables', 'Add sauce', 'Serve with rice'],
            'prep_time': 10, 'cook_time': 10, 'servings': 2,
            'calories': 280, 'protein': 8, 'carbs': 35, 'fat': 12,
            'tags': ['dinner', 'vegetarian', 'quick', 'healthy']
        },
        'overnight_oats': {
            'name': 'Overnight Oats',
            'description': 'Healthy make-ahead breakfast',
            'ingredients': ['oats', 'milk', 'yogurt', 'honey', 'fruits', 'nuts'],
            'instructions': ['Mix oats and milk', 'Add yogurt', 
                           'Top with fruits', 'Refrigerate overnight'],
            'prep_time': 5, 'cook_time': 0, 'servings': 1,
            'calories': 320, 'protein': 12, 'carbs': 55, 'fat': 8,
            'tags': ['breakfast', 'meal-prep', 'healthy']
        },
        'pasta_marinara': {
            'name': 'Pasta with Marinara',
            'description': 'Classic Italian pasta',
            'ingredients': ['pasta', 'tomatoes', 'garlic', 'basil', 
                          'olive oil', 'parmesan'],
            'instructions': ['Boil pasta', 'Make sauce', 
                           'Combine and serve', 'Top with cheese'],
            'prep_time': 10, 'cook_time': 20, 'servings': 4,
            'calories': 420, 'protein': 12, 'carbs': 72, 'fat': 10,
            'tags': ['dinner', 'italian', 'vegetarian']
        },
        'smoothie_bowl': {
            'name': 'Smoothie Bowl',
            'description': 'Healthy fruit smoothie bowl',
            'ingredients': ['bananas', 'berries', 'yogurt', 'granola', 'honey'],
            'instructions': ['Blend frozen fruits', 'Pour into bowl', 
                           'Top with granola', 'Drizzle honey'],
            'prep_time': 10, 'cook_time': 0, 'servings': 1,
            'calories': 350, 'protein': 10, 'carbs': 65, 'fat': 8,
            'tags': ['breakfast', 'healthy', 'quick']
        },
        'grilled_cheese': {
            'name': 'Grilled Cheese Sandwich',
            'description': 'Classic comfort food',
            'ingredients': ['bread', 'cheese', 'butter'],
            'instructions': ['Butter bread', 'Add cheese', 
                           'Grill until golden', 'Serve hot'],
            'prep_time': 5, 'cook_time': 10, 'servings': 1,
            'calories': 400, 'protein': 15, 'carbs': 35, 'fat': 22,
            'tags': ['lunch', 'quick', 'comfort-food']
        },
        'fish_tacos': {
            'name': 'Fish Tacos',
            'description': 'Fresh and flavorful tacos',
            'ingredients': ['fish', 'tortillas', 'cabbage', 'lime', 
                          'cilantro', 'sour cream'],
            'instructions': ['Season fish', 'Grill or pan-fry', 
                           'Warm tortillas', 'Assemble tacos'],
            'prep_time': 15, 'cook_time': 15, 'servings': 2,
            'calories': 450, 'protein': 30, 'carbs': 40, 'fat': 18,
            'tags': ['dinner', 'mexican', 'seafood']
        },
        'fruit_yogurt': {
            'name': 'Fruit and Yogurt',
            'description': 'Simple healthy snack',
            'ingredients': ['yogurt', 'fruits', 'honey', 'granola'],
            'instructions': ['Layer yogurt and fruits', 
                           'Top with granola', 'Drizzle honey'],
            'prep_time': 5, 'cook_time': 0, 'servings': 1,
            'calories': 250, 'protein': 10, 'carbs': 40, 'fat': 5,
            'tags': ['snack', 'healthy', 'quick']
        }
    }
    
    @classmethod
    def get_all_recipes(cls) -> List[Recipe]:
        recipes = []
        for key, data in cls.RECIPES.items():
            recipes.append(Recipe(
                id=hash(key) % 10000,
                name=data['name'],
                description=data['description'],
                ingredients=data['ingredients'],
                instructions=data['instructions'],
                prep_time=data['prep_time'],
                cook_time=data['cook_time'],
                servings=data['servings'],
                calories=data['calories'],
                protein=data['protein'],
                carbs=data['carbs'],
                fat=data['fat'],
                tags=data['tags']
            ))
        return recipes
    
    @classmethod
    def search_recipes(cls, query: str = None, 
                      tags: List[str] = None) -> List[Recipe]:
        results = []
        for recipe in cls.get_all_recipes():
            if query:
                query_lower = query.lower()
                if (query_lower not in recipe.name.lower() and
                    query_lower not in recipe.description.lower() and
                    not any(query_lower in ing.lower() for ing in recipe.ingredients)):
                    continue
            
            if tags:
                if not any(tag in recipe.tags for tag in tags):
                    continue
            
            results.append(recipe)
        
        return results
    
    @classmethod
    def get_recipe_by_name(cls, name: str) -> Optional[Recipe]:
        for key, data in cls.RECIPES.items():
            if name.lower() in data['name'].lower():
                return Recipe(
                    id=hash(key) % 10000,
                    name=data['name'],
                    description=data['description'],
                    ingredients=data['ingredients'],
                    instructions=data['instructions'],
                    prep_time=data['prep_time'],
                    cook_time=data['cook_time'],
                    servings=data['servings'],
                    calories=data['calories'],
                    protein=data['protein'],
                    carbs=data['carbs'],
                    fat=data['fat'],
                    tags=data['tags']
                )
        return None


class MealPlanner:
    """Main meal planning system"""
    
    def __init__(self, db_path: str = "data/refrigerator.db"):
        self.db_path = db_path
    
    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def add_meal_plan(self, name: str, description: str, date: str,
                     meal_type: str, ingredients: str, instructions: str,
                     calories: int = 0, prep_time: int = 0) -> int:
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO meal_plans (name, description, date, meal_type,
                                  ingredients, instructions, calories, prep_time)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (name, description, date, meal_type, ingredients,
              instructions, calories, prep_time))
        
        plan_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return plan_id
    
    def get_meal_plans(self, start_date: str = None, 
                      end_date: str = None) -> List[Dict]:
        conn = self._get_connection()
        cursor = conn.cursor()
        
        if start_date and end_date:
            cursor.execute('''
                SELECT * FROM meal_plans 
                WHERE date BETWEEN ? AND ?
                ORDER BY date, meal_type
            ''', (start_date, end_date))
        elif start_date:
            cursor.execute('''
                SELECT * FROM meal_plans 
                WHERE date >= ?
                ORDER BY date, meal_type
            ''', (start_date,))
        else:
            cursor.execute('''
                SELECT * FROM meal_plans 
                ORDER BY date DESC, meal_type
            ''')
        
        plans = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        return plans
    
    def get_daily_plan(self, date: str) -> Dict[str, Optional[Dict]]:
        plans = self.get_meal_plans(date, date)
        
        daily = {
            'breakfast': None,
            'lunch': None,
            'dinner': None,
            'snack': None
        }
        
        for plan in plans:
            meal_type = plan.get('meal_type', 'snack')
            if meal_type in daily:
                daily[meal_type] = plan
        
        return daily
    
    def get_weekly_plan(self, start_date: datetime = None) -> Dict:
        if start_date is None:
            start_date = datetime.now()
        
        week_plan = {}
        
        for i in range(7):
            day = start_date + timedelta(days=i)
            date_str = day.strftime("%Y-%m-%d")
            week_plan[date_str] = self.get_daily_plan(date_str)
        
        return week_plan
    
    def delete_meal_plan(self, plan_id: int):
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM meal_plans WHERE id = ?', (plan_id,))
        conn.commit()
        conn.close()
    
    def generate_weekly_plan(self, start_date: datetime = None,
                            preferences: Dict = None) -> List[Dict]:
        """Automatically generate a weekly meal plan"""
        if start_date is None:
            start_date = datetime.now()
        
        recipes = RecipeDatabase.get_all_recipes()
        
        meal_types = ['breakfast', 'lunch', 'dinner']
        generated_plans = []
        
        for i in range(7):
            date = start_date + timedelta(days=i)
            date_str = date.strftime("%Y-%m-%d")
            
            for meal_type in meal_types:
                suitable_recipes = [
                    r for r in recipes 
                    if meal_type in r.tags or meal_type == r.tags[0]
                ]
                
                if suitable_recipes:
                    recipe = suitable_recipes[i % len(suitable_recipes)]
                    
                    plan_id = self.add_meal_plan(
                        name=recipe.name,
                        description=recipe.description,
                        date=date_str,
                        meal_type=meal_type,
                        ingredients=', '.join(recipe.ingredients),
                        instructions='\n'.join(recipe.instructions),
                        calories=recipe.calories,
                        prep_time=recipe.prep_time + recipe.cook_time
                    )
                    
                    generated_plans.append({
                        'id': plan_id,
                        'date': date_str,
                        'meal_type': meal_type,
                        'recipe': recipe
                    })
        
        return generated_plans
    
    def calculate_daily_nutrition(self, date: str) -> Dict:
        plans = self.get_meal_plans(date, date)
        
        totals = {
            'calories': 0,
            'protein': 0,
            'carbs': 0,
            'fat': 0,
            'meals_planned': len(plans)
        }
        
        for plan in plans:
            totals['calories'] += plan.get('calories', 0)
        
        return totals
    
    def get_shopping_list(self, start_date: str, end_date: str) -> Dict[str, float]:
        """Generate shopping list from meal plans"""
        plans = self.get_meal_plans(start_date, end_date)
        
        shopping = {}
        
        for plan in plans:
            ingredients_str = plan.get('ingredients', '')
            ingredients = [ing.strip() for ing in ingredients_str.split(',')]
            
            for ingredient in ingredients:
                ingredient_lower = ingredient.lower()
                if ingredient_lower not in shopping:
                    shopping[ingredient_lower] = 0
                shopping[ingredient_lower] += 1
        
        return shopping
    
    def suggest_meals_for_inventory(self, available_items: List[str]) -> List[Dict]:
        """Suggest meals based on available inventory"""
        available_lower = [item.lower() for item in available_items]
        
        suggestions = []
        
        for recipe in RecipeDatabase.get_all_recipes():
            recipe_ingredients = [ing.lower() for ing in recipe.ingredients]
            
            matches = sum(1 for ing in recipe_ingredients if any(
                ing in available or available in ing 
                for available in available_lower
            ))
            
            if matches > 0:
                match_percentage = (matches / len(recipe_ingredients)) * 100
                
                suggestions.append({
                    'recipe': recipe.name,
                    'description': recipe.description,
                    'match_percentage': round(match_percentage, 1),
                    'missing_ingredients': [
                        ing for ing in recipe_ingredients
                        if not any(ing in available or available in ing 
                                  for available in available_lower)
                    ],
                    'calories': recipe.calories,
                    'prep_time': recipe.prep_time + recipe.cook_time,
                    'tags': recipe.tags
                })
        
        suggestions.sort(key=lambda x: x['match_percentage'], reverse=True)
        
        return suggestions


class NutritionTracker:
    """Track daily nutrition intake"""
    
    NUTRIENT_GOALS = {
        'calories': 2000,
        'protein': 50,
        'carbs': 300,
        'fat': 65
    }
    
    def __init__(self, db_path: str = "data/refrigerator.db"):
        self.db_path = db_path
    
    def log_meal(self, meal_plan_id: int, servings: float = 1.0):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO meal_schedule (meal_plan_id, date, meal_type, status)
            VALUES (?, date('now'), 
                   (SELECT meal_type FROM meal_plans WHERE id = ?),
                   'completed')
        ''', (meal_plan_id, meal_plan_id))
        
        conn.commit()
        conn.close()
    
    def get_daily_summary(self, date: str = None) -> Dict:
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
        
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT SUM(calories) as total_calories,
                   COUNT(*) as meals_logged
            FROM meal_plans
            WHERE date = ?
        ''', (date,))
        
        row = cursor.fetchone()
        conn.close()
        
        total_calories = row['total_calories'] or 0
        meals_logged = row['meals_logged'] or 0
        
        return {
            'date': date,
            'calories_consumed': total_calories,
            'calories_remaining': self.NUTRIENT_GOALS['calories'] - total_calories,
            'meals_logged': meals_logged,
            'goal_percentage': round(
                (total_calories / self.NUTRIENT_GOALS['calories']) * 100, 1
            )
        }


if __name__ == "__main__":
    print("=" * 60)
    print("MEAL PLANNER - DEMO")
    print("=" * 60)
    
    planner = MealPlanner()
    
    print("\n[1] Available Recipes:")
    recipes = RecipeDatabase.get_all_recipes()
    for recipe in recipes[:5]:
        print(f"  - {recipe.name} ({recipe.calories} cal, "
              f"{recipe.prep_time + recipe.cook_time} min)")
    
    print("\n[2] Searching recipes with 'chicken':")
    results = RecipeDatabase.search_recipes('chicken')
    for recipe in results:
        print(f"  - {recipe.name}")
    
    print("\n[3] Getting today's meal plan:")
    today = datetime.now().strftime("%Y-%m-%d")
    daily = planner.get_daily_plan(today)
    for meal_type, plan in daily.items():
        if plan:
            print(f"  {meal_type}: {plan['name']}")
        else:
            print(f"  {meal_type}: Not planned")
    
    print("\n[4] Calculating daily nutrition:")
    nutrition = planner.calculate_daily_nutrition(today)
    print(f"  Meals planned: {nutrition['meals_planned']}")
    print(f"  Total calories: {nutrition['calories']}")
    
    print("\n" + "=" * 60)
    print("MEAL PLANNER DEMO COMPLETE")
    print("=" * 60)
