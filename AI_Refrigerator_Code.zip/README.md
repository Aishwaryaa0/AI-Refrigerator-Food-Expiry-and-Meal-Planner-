# AI Refrigerator - Food Expiry & Meal Planner

## Quick Start

### 1. Install Dependencies
```bash
cd ai-refrigerator
pip install -r requirements.txt
```

### 2. Run CLI Application
```bash
python src/main.py
```

### 3. Run Web Dashboard
```bash
python src/web_dashboard.py
```
Then open http://127.0.0.1:5000 in your browser

## Features

- **Food Inventory Management** - Track items with expiry dates
- **Simulated Sensors** - Temperature, humidity, gas levels
- **AI Freshness Prediction** - ML-based spoilage detection
- **Meal Planner** - Plan weekly meals
- **Alert System** - Notifications for expiring items
- **Reports** - Inventory summaries and waste tracking

## Project Structure
```
ai-refrigerator/
├── src/
│   ├── main.py           # CLI application
│   ├── web_dashboard.py  # Flask web app
│   ├── database.py       # SQLite database
│   ├── sensor_simulation.py  # Hardware simulation
│   ├── inventory.py      # Food management
│   ├── ml_model.py       # AI/ML predictions
│   └── meal_planner.py   # Meal planning
├── templates/            # HTML templates
├── data/                 # SQLite database
└── requirements.txt     # Python dependencies
```

## Specification Compliance

| Requirement | Status |
|-------------|--------|
| Real-time monitoring | ✅ Simulated |
| Gas spoilage detection | ✅ MQ-135 simulated |
| Temperature/Humidity | ✅ DHT22/BME280 simulated |
| Weight tracking | ✅ HX711 simulated |
| AI Freshness prediction | ✅ scikit-learn model |
| Web dashboard | ✅ Flask web app |
| Meal planner | ✅ Full system |
| Alerts | ✅ Desktop notifications |
