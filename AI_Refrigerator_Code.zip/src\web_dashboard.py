"""
Flask Web Dashboard for AI Refrigerator System
Run with: python src/web_dashboard.py
"""

from flask import Flask, render_template, jsonify, request, redirect, url_for
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.secret_key = 'ai-refrigerator-secret-key'

sys_path = os.path.dirname(os.path.abspath(__file__))
import sys
sys.path.insert(0, sys_path)

from database import Database
from sensor_simulation import SensorSimulator
from inventory import FoodInventory
from ml_model import FreshnessPredictor
from meal_planner import MealPlanner

db = Database()
sensor = SensorSimulator()
inventory = FoodInventory()
predictor = FreshnessPredictor()
meal_planner = MealPlanner()

@app.route('/')
def index():
    stats = db.get_statistics()
    alerts = db.get_alerts(unread_only=True)
    expiring = db.get_expiring_foods(3)
    return render_template('index.html', 
                         stats=stats, 
                         alerts=alerts,
                         expiring=expiring,
                         now=datetime.now())

@app.route('/api/dashboard')
def api_dashboard():
    stats = db.get_statistics()
    readings = sensor.get_all_readings()
    return jsonify({
        'stats': stats,
        'sensors': readings
    })

@app.route('/inventory')
def inventory_page():
    items = db.get_all_food_items()
    categories = db.get_food_categories()
    return render_template('inventory.html', items=items, categories=categories)

@app.route('/inventory/add', methods=['POST'])
def add_item():
    name = request.form.get('name')
    category = request.form.get('category', 'Other')
    quantity = float(request.form.get('quantity', 1))
    unit = request.form.get('unit', 'pieces')
    expiry_days = int(request.form.get('expiry_days', 7))
    
    purchase_date = datetime.now().strftime("%Y-%m-%d")
    expiry_date = (datetime.now() + timedelta(days=expiry_days)).strftime("%Y-%m-%d")
    
    db.add_food_item(name, category, quantity, unit, purchase_date, expiry_date)
    return redirect(url_for('inventory_page'))

@app.route('/inventory/delete/<int:item_id>')
def delete_item(item_id):
    db.delete_food_item(item_id)
    return redirect(url_for('inventory_page'))

@app.route('/sensors')
def sensors_page():
    readings = sensor.get_all_readings()
    history = db.get_sensor_history(24)
    return render_template('sensors.html', readings=readings, history=history)

@app.route('/api/sensors')
def api_sensors():
    readings = sensor.get_all_readings()
    db.add_sensor_reading(readings['temperature'], readings['humidity'], 
                         readings['gas_level'], 0)
    return jsonify(readings)

@app.route('/predictions')
def predictions_page():
    items = db.get_all_food_items()
    readings = sensor.get_all_readings()
    sensor_data = {
        'temperature': readings['temperature'],
        'humidity': readings['humidity'],
        'gas_level': readings['gas_level']
    }
    predictions = []
    for item in items:
        analysis = predictor.get_freshness_analysis(item, sensor_data)
        predictions.append({
            'item': item,
            'analysis': analysis
        })
    return render_template('predictions.html', predictions=predictions)

@app.route('/meals')
def meals_page():
    today = datetime.now().strftime("%Y-%m-%d")
    daily = meal_planner.get_daily_plan(today)
    week_plan = meal_planner.get_weekly_plan()
    return render_template('meals.html', daily=daily, week_plan=week_plan, now=datetime.now())

@app.route('/meals/add', methods=['POST'])
def add_meal():
    name = request.form.get('name')
    description = request.form.get('description', '')
    date = request.form.get('date', datetime.now().strftime("%Y-%m-%d"))
    meal_type = request.form.get('meal_type', 'lunch')
    ingredients = request.form.get('ingredients', '')
    instructions = request.form.get('instructions', '')
    calories = int(request.form.get('calories', 0))
    prep_time = int(request.form.get('prep_time', 15))
    
    meal_planner.add_meal_plan(name, description, date, meal_type,
                              ingredients, instructions, calories, prep_time)
    return redirect(url_for('meals_page'))

@app.route('/reports')
def reports_page():
    summary = inventory.get_inventory_summary()
    expiring = db.get_expiring_foods(7)
    expired = db.get_expired_foods()
    return render_template('reports.html', 
                         summary=summary, 
                         expiring=expiring,
                         expired=expired)

@app.route('/alerts')
def alerts_page():
    alerts = db.get_alerts()
    return render_template('alerts.html', alerts=alerts)

@app.route('/alerts/dismiss/<int:alert_id>')
def dismiss_alert(alert_id):
    db.dismiss_alert(alert_id)
    return redirect(url_for('alerts_page'))

if __name__ == '__main__':
    print("Starting AI Refrigerator Web Dashboard...")
    print("Open http://127.0.0.1:5000 in your browser")
    app.run(debug=True, host='127.0.0.1', port=5000)
