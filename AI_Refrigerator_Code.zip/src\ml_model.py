"""
AI/ML Model for Food Freshness Prediction
Uses scikit-learn for training and prediction
"""

import numpy as np
import pandas as pd
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass

try:
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
    from sklearn.preprocessing import StandardScaler, LabelEncoder
    from sklearn.model_selection import train_test_split, cross_val_score
    from sklearn.metrics import classification_report, mean_absolute_error, r2_score
    import joblib
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    print("scikit-learn not available. Using rule-based prediction.")


@dataclass
class FreshnessPrediction:
    food_name: str
    freshness_score: float
    days_until_expiry: int
    status: str
    confidence: float
    recommendations: List[str]


class FreshnessPredictor:
    """
    AI-based food freshness prediction model
    Uses sensor data and food characteristics to predict freshness
    """
    
    def __init__(self, model_dir: str = "models"):
        self.model_dir = model_dir
        self.freshness_model = None
        self.spoilage_model = None
        self.scaler = None
        self.label_encoder = None
        self.is_trained = False
        
        os.makedirs(model_dir, exist_ok=True)
        
        if SKLEARN_AVAILABLE:
            self._load_models()
        else:
            self._init_rule_based_system()
    
    def _init_rule_based_system(self):
        """Initialize rule-based prediction system"""
        self.freshness_rules = {
            'dairy': {'base_days': 7, 'spoilage_temp': 8, 'gas_threshold': 80},
            'meat': {'base_days': 3, 'spoilage_temp': 6, 'gas_threshold': 100},
            'vegetables': {'base_days': 7, 'spoilage_temp': 10, 'gas_threshold': 60},
            'fruits': {'base_days': 10, 'spoilage_temp': 12, 'gas_threshold': 70},
            'seafood': {'base_days': 2, 'spoilage_temp': 4, 'gas_threshold': 120},
            'default': {'base_days': 5, 'spoilage_temp': 6, 'gas_threshold': 100}
        }
    
    def _load_models(self):
        """Load pre-trained models if available"""
        freshness_path = os.path.join(self.model_dir, "freshness_model.pkl")
        scaler_path = os.path.join(self.model_dir, "scaler.pkl")
        
        if os.path.exists(freshness_path) and os.path.exists(scaler_path):
            try:
                self.freshness_model = joblib.load(freshness_path)
                self.scaler = joblib.load(scaler_path)
                self.is_trained = True
                print("Pre-trained models loaded successfully!")
            except Exception as e:
                print(f"Error loading models: {e}")
                self._init_rule_based_system()
    
    def train(self, training_data_path: str = None):
        """Train the freshness prediction model"""
        if not SKLEARN_AVAILABLE:
            print("scikit-learn not available. Using rule-based system.")
            return False
        
        print("Training Freshness Prediction Model...")
        
        if training_data_path and os.path.exists(training_data_path):
            df = pd.read_csv(training_data_path)
        else:
            df = self._generate_training_data()
        
        X = df[['temperature', 'humidity', 'gas_level', 'days_stored', 'category_encoded']]
        y = df['freshness_score']
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        self.freshness_model = GradientBoostingRegressor(
            n_estimators=100,
            max_depth=5,
            learning_rate=0.1,
            random_state=42
        )
        self.freshness_model.fit(X_train_scaled, y_train)
        
        y_pred = self.freshness_model.predict(X_test_scaled)
        mae = mean_absolute_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        print(f"Model Training Complete!")
        print(f"Mean Absolute Error: {mae:.2f}")
        print(f"R² Score: {r2:.2f}")
        
        cv_scores = cross_val_score(
            self.freshness_model, X_train_scaled, y_train, cv=5
        )
        print(f"Cross-validation Score: {cv_scores.mean():.2f} (+/- {cv_scores.std()*2:.2f})")
        
        self._save_models()
        self.is_trained = True
        
        return True
    
    def _generate_training_data(self, samples: int = 1000) -> pd.DataFrame:
        """Generate synthetic training data"""
        np.random.seed(42)
        
        categories = ['dairy', 'meat', 'vegetables', 'fruits', 'seafood']
        
        data = {
            'temperature': np.random.uniform(0, 15, samples),
            'humidity': np.random.uniform(20, 90, samples),
            'gas_level': np.random.uniform(20, 200, samples),
            'days_stored': np.random.randint(0, 30, samples),
            'category_encoded': np.random.randint(0, 5, samples),
        }
        
        freshness_scores = []
        for i in range(samples):
            temp = data['temperature'][i]
            humidity = data['humidity'][i]
            gas = data['gas_level'][i]
            days = data['days_stored'][i]
            cat = categories[data['category_encoded'][i]]
            
            base_freshness = 100
            
            if cat == 'dairy':
                base_freshness -= days * 5 + max(0, (temp - 5) * 5) + max(0, (gas - 60) * 0.3)
            elif cat == 'meat':
                base_freshness -= days * 10 + max(0, (temp - 3) * 8) + max(0, (gas - 70) * 0.4)
            elif cat == 'seafood':
                base_freshness -= days * 15 + max(0, (temp - 2) * 10) + max(0, (gas - 80) * 0.5)
            else:
                base_freshness -= days * 3 + max(0, (temp - 8) * 3) + max(0, (gas - 50) * 0.2)
            
            freshness_scores.append(max(0, min(100, base_freshness + np.random.normal(0, 5))))
        
        data['freshness_score'] = freshness_scores
        
        return pd.DataFrame(data)
    
    def _save_models(self):
        """Save trained models to disk"""
        if self.freshness_model and self.scaler:
            joblib.dump(self.freshness_model, 
                       os.path.join(self.model_dir, "freshness_model.pkl"))
            joblib.dump(self.scaler, 
                       os.path.join(self.model_dir, "scaler.pkl"))
            print("Models saved successfully!")
    
    def predict(self, temperature: float, humidity: float, gas_level: float,
                days_stored: int, category: str) -> float:
        """Predict freshness score (0-100)"""
        
        if SKLEARN_AVAILABLE and self.is_trained and self.freshness_model:
            category_map = {
                'dairy': 0, 'meat': 1, 'vegetables': 2, 
                'fruits': 3, 'seafood': 4
            }
            
            cat_encoded = category_map.get(category.lower(), 0)
            
            features = np.array([[temperature, humidity, gas_level, days_stored, cat_encoded]])
            features_scaled = self.scaler.transform(features)
            
            prediction = self.freshness_model.predict(features_scaled)[0]
            
            return max(0, min(100, prediction))
        
        return self._rule_based_prediction(
            temperature, humidity, gas_level, days_stored, category
        )
    
    def _rule_based_prediction(self, temperature: float, humidity: float,
                               gas_level: float, days_stored: int,
                               category: str) -> float:
        """Rule-based freshness prediction"""
        
        cat_lower = category.lower()
        rules = self.freshness_rules.get(
            cat_lower if cat_lower in self.freshness_rules else 'default',
            self.freshness_rules['default']
        )
        
        base_freshness = 100
        
        days_factor = (days_stored / rules['base_days']) * 100
        base_freshness -= days_factor
        
        if temperature > rules['spoilage_temp']:
            temp_penalty = (temperature - rules['spoilage_temp']) * 10
            base_freshness -= temp_penalty
        
        if gas_level > rules['gas_threshold']:
            gas_penalty = (gas_level - rules['gas_threshold']) * 0.2
            base_freshness -= gas_penalty
        
        humidity_low = 30
        humidity_high = 70
        if humidity < humidity_low:
            base_freshness -= (humidity_low - humidity) * 0.2
        elif humidity > humidity_high:
            base_freshness -= (humidity - humidity_high) * 0.2
        
        return max(0, min(100, round(base_freshness, 1)))
    
    def predict_expiry(self, food_name: str, category: str,
                      purchase_date: datetime, 
                      current_conditions: Dict) -> Tuple[int, float]:
        """
        Predict days until expiry and confidence
        Returns: (days_until_expiry, confidence)
        """
        
        freshness = self.predict(
            current_conditions.get('temperature', 4.0),
            current_conditions.get('humidity', 45.0),
            current_conditions.get('gas_level', 50.0),
            (datetime.now() - purchase_date).days,
            category
        )
        
        if freshness >= 80:
            days_remaining = 5
            confidence = 0.9
        elif freshness >= 60:
            days_remaining = 3
            confidence = 0.8
        elif freshness >= 40:
            days_remaining = 1
            confidence = 0.7
        else:
            days_remaining = 0
            confidence = 0.9
        
        return days_remaining, confidence
    
    def get_freshness_analysis(self, food_data: Dict, 
                             sensor_readings: Dict) -> FreshnessPrediction:
        """Get comprehensive freshness analysis"""
        
        temperature = sensor_readings.get('temperature', 4.0)
        humidity = sensor_readings.get('humidity', 45.0)
        gas_level = sensor_readings.get('gas_level', 50.0)
        
        purchase_date = datetime.strptime(
            food_data.get('purchase_date', datetime.now().strftime("%Y-%m-%d")),
            "%Y-%m-%d"
        )
        days_stored = (datetime.now() - purchase_date).days
        category = food_data.get('category', 'default')
        
        freshness = self.predict(
            temperature, humidity, gas_level, days_stored, category
        )
        
        expiry_date = datetime.strptime(
            food_data.get('expiry_date', (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")),
            "%Y-%m-%d"
        )
        days_until_expiry = (expiry_date - datetime.now()).days
        
        if freshness >= 70:
            status = "fresh"
        elif freshness >= 40:
            status = "expiring_soon"
        else:
            status = "spoiled"
        
        recommendations = self._generate_recommendations(
            freshness, category, days_until_expiry
        )
        
        confidence = 0.85 if freshness > 50 else 0.7
        
        return FreshnessPrediction(
            food_name=food_data.get('name', 'Unknown'),
            freshness_score=freshness,
            days_until_expiry=days_until_expiry,
            status=status,
            confidence=confidence,
            recommendations=recommendations
        )
    
    def _generate_recommendations(self, freshness: float, 
                                  category: str, 
                                  days_until_expiry: int) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        
        if freshness < 30:
            recommendations.append("⚠️ Food is likely spoiled. Consume immediately or discard.")
        elif freshness < 50:
            recommendations.append("⚡ Food is expiring soon. Consider consuming today.")
        
        if days_until_expiry <= 0:
            recommendations.append("❌ Food has expired. Do not consume.")
        elif days_until_expiry <= 1:
            recommendations.append("🔴 Expires tomorrow. Use today.")
        elif days_until_expiry <= 3:
            recommendations.append("🟡 Expiring soon. Plan to use within 3 days.")
        
        if category.lower() == 'meat':
            recommendations.append("🥩 Store at lowest temperature possible.")
            recommendations.append("🍳 Consider cooking today for best quality.")
        elif category.lower() == 'dairy':
            recommendations.append("🧀 Can be used in cooking/baking if not fresh enough for direct consumption.")
        elif category.lower() == 'vegetables':
            recommendations.append("🥬 Can be frozen for later use if not used soon.")
        
        if freshness > 70:
            recommendations.append("✅ Food is in good condition. Enjoy!")
        
        return recommendations


class SpoilageDetector:
    """Detects food spoilage based on gas emissions"""
    
    SPOILAGE_INDICATORS = {
        'ammonia': {'threshold': 50, 'foods': ['meat', 'fish', 'dairy']},
        'hydrogen_sulfide': {'threshold': 30, 'foods': ['meat', 'eggs']},
        'methane': {'threshold': 100, 'foods': ['vegetables', 'fruits']},
        'co2': {'threshold': 800, 'foods': ['all']},
        'ethanol': {'threshold': 50, 'foods': ['fruits', 'vegetables']},
    }
    
    def __init__(self):
        self.alert_history = []
    
    def analyze_gases(self, gas_readings: Dict[str, float]) -> Dict:
        """Analyze gas readings for spoilage indicators"""
        results = {
            'spoilage_detected': False,
            'severity': 'none',
            'indicators': [],
            'confidence': 0.0
        }
        
        spoilage_count = 0
        total_indicators = len(gas_readings)
        
        for gas, level in gas_readings.items():
            if gas in self.SPOILAGE_INDICATORS:
                indicator = self.SPOILAGE_INDICATORS[gas]
                if level > indicator['threshold']:
                    spoilage_count += 1
                    results['indicators'].append({
                        'gas': gas,
                        'level': level,
                        'threshold': indicator['threshold'],
                        'severity': 'high' if level > indicator['threshold'] * 2 else 'medium'
                    })
        
        if spoilage_count > 0:
            results['spoilage_detected'] = True
            results['severity'] = 'high' if spoilage_count > 2 else 'medium'
            results['confidence'] = spoilage_count / total_indicators
        
        self.alert_history.append({
            'timestamp': datetime.now().isoformat(),
            'results': results.copy()
        })
        
        return results
    
    def detect_protein_spoilage(self, ammonia: float, 
                               hydrogen_sulfide: float) -> bool:
        """Specific detection for protein-based food spoilage"""
        return (ammonia > 50 or hydrogen_sulfide > 30)
    
    def detect_vegetable_spoilage(self, ethylene: float, 
                                 ethanol: float) -> bool:
        """Specific detection for vegetable spoilage"""
        return (ethylene > 100 or ethanol > 80)


class MealRecommender:
    """AI-based meal recommendation based on available ingredients"""
    
    MEAL_RECIPES = {
        'breakfast': [
            {'name': 'Scrambled Eggs', 'ingredients': ['eggs', 'butter'], 'priority': 1},
            {'name': 'Oatmeal with Fruits', 'ingredients': ['oats', 'fruits'], 'priority': 2},
            {'name': 'Yogurt Parfait', 'ingredients': ['yogurt', 'fruits'], 'priority': 1},
            {'name': 'Toast with Cheese', 'ingredients': ['bread', 'cheese'], 'priority': 2},
        ],
        'lunch': [
            {'name': 'Chicken Salad', 'ingredients': ['chicken', 'lettuce', 'tomatoes'], 'priority': 1},
            {'name': 'Grilled Cheese Sandwich', 'ingredients': ['bread', 'cheese', 'butter'], 'priority': 2},
            {'name': 'Vegetable Stir Fry', 'ingredients': ['vegetables', 'rice'], 'priority': 1},
            {'name': 'Pasta with Tomato Sauce', 'ingredients': ['pasta', 'tomatoes'], 'priority': 2},
        ],
        'dinner': [
            {'name': 'Grilled Chicken with Vegetables', 'ingredients': ['chicken', 'vegetables'], 'priority': 1},
            {'name': 'Beef Stir Fry', 'ingredients': ['beef', 'vegetables', 'rice'], 'priority': 1},
            {'name': 'Fish Curry', 'ingredients': ['fish', 'vegetables'], 'priority': 2},
            {'name': 'Vegetarian Curry', 'ingredients': ['vegetables', 'rice'], 'priority': 1},
        ]
    }
    
    def __init__(self, inventory):
        self.inventory = inventory
    
    def get_recommendations(self, meal_type: str = None, 
                           max_expiring_first: bool = True) -> List[Dict]:
        """Get meal recommendations based on available ingredients"""
        
        items = self.inventory.get_all_items()
        available_foods = {item['name'].lower() for item in items}
        
        expiring_items = self.inventory.get_expiring_items(3)
        expiring_foods = {item['name'].lower() for item in expiring_items}
        
        recommendations = []
        
        meal_types = [meal_type] if meal_type else ['breakfast', 'lunch', 'dinner']
        
        for meal in meal_types:
            if meal not in self.MEAL_RECIPES:
                continue
            
            for recipe in self.MEAL_RECIPES[meal]:
                ingredients = [ing.lower() for ing in recipe['ingredients']]
                
                matches = sum(1 for ing in ingredients if ing in available_foods)
                expiring_matches = sum(1 for ing in ingredients if ing in expiring_foods)
                
                if matches > 0:
                    match_percentage = (matches / len(ingredients)) * 100
                    
                    priority = recipe['priority']
                    if expiring_matches > 0 and max_expiring_first:
                        priority = 0
                    
                    recommendations.append({
                        'meal_type': meal,
                        'name': recipe['name'],
                        'match_percentage': match_percentage,
                        'ingredients_available': matches,
                        'total_ingredients': len(ingredients),
                        'uses_expiring': expiring_matches > 0,
                        'priority': priority
                    })
        
        recommendations.sort(key=lambda x: (-x['priority'], -x['match_percentage']))
        
        return recommendations[:10]
    
    def suggest_recipes_for_expiring(self) -> List[Dict]:
        """Suggest recipes that use expiring food items first"""
        expiring = self.inventory.get_expiring_items(3)
        
        suggestions = []
        for item in expiring:
            recommendations = self.get_recommendations()
            
            for rec in recommendations:
                if item['name'].lower() in rec['name'].lower():
                    suggestions.append({
                        'recipe': rec['name'],
                        'meal_type': rec['meal_type'],
                        'expiring_ingredient': item['name'],
                        'expires_in': (datetime.strptime(item['expiry_date'], "%Y-%m-%d") - datetime.now()).days,
                        'match_percentage': rec['match_percentage']
                    })
        
        return suggestions


if __name__ == "__main__":
    print("=" * 60)
    print("AI FRESHNESS PREDICTION MODEL - DEMO")
    print("=" * 60)
    
    predictor = FreshnessPredictor()
    
    print("\n[1] Training model with synthetic data...")
    predictor.train()
    
    print("\n[2] Testing predictions...")
    test_cases = [
        {'temp': 4, 'humidity': 45, 'gas': 50, 'days': 1, 'category': 'dairy'},
        {'temp': 6, 'humidity': 55, 'gas': 80, 'days': 2, 'category': 'meat'},
        {'temp': 3, 'humidity': 40, 'gas': 60, 'days': 1, 'category': 'fish'},
        {'temp': 8, 'humidity': 50, 'gas': 70, 'days': 3, 'category': 'vegetables'},
    ]
    
    print("\nPredictions:")
    for tc in test_cases:
        freshness = predictor.predict(
            tc['temp'], tc['humidity'], tc['gas'], tc['days'], tc['category']
        )
        print(f"  {tc['category'].title()}: {freshness:.1f}% freshness "
              f"(T={tc['temp']}°C, Gas={tc['gas']})")
    
    print("\n[3] Testing spoilage detection...")
    detector = SpoilageDetector()
    gas_readings = {
        'ammonia': 60,
        'hydrogen_sulfide': 25,
        'co2': 600,
        'ethanol': 40
    }
    result = detector.analyze_gases(gas_readings)
    print(f"  Spoilage Detected: {result['spoilage_detected']}")
    print(f"  Severity: {result['severity']}")
    print(f"  Indicators: {len(result['indicators'])}")
    
    print("\n" + "=" * 60)
    print("MODEL DEMO COMPLETE")
    print("=" * 60)
