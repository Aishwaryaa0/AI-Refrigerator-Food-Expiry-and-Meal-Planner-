"""
Main CLI Application for AI Refrigerator System
Provides console-based interface for all features
"""

import os
import sys
import time
import argparse
from datetime import datetime, timedelta
from typing import Optional

try:
    from colorama import init, Fore, Back, Style
    init(autoreset=True)
    COLORAMA_AVAILABLE = True
except ImportError:
    COLORAMA_AVAILABLE = False

from database import Database
from sensor_simulation import SensorSimulator, FoodSpoilageSimulator
from inventory import FoodInventory
from ml_model import FreshnessPredictor, SpoilageDetector, MealRecommender
from meal_planner import MealPlanner, RecipeDatabase


class Colors:
    if COLORAMA_AVAILABLE:
        HEADER = Fore.CYAN + Style.BRIGHT
        SUCCESS = Fore.GREEN + Style.BRIGHT
        WARNING = Fore.YELLOW + Style.BRIGHT
        ERROR = Fore.RED + Style.BRIGHT
        INFO = Fore.BLUE + Style.BRIGHT
        DIM = Fore.WHITE + Style.DIM
        RESET = Style.RESET_ALL
    else:
        HEADER = ""
        SUCCESS = ""
        WARNING = ""
        ERROR = ""
        INFO = ""
        DIM = ""
        RESET = ""


class CLIApp:
    """Main CLI Application"""
    
    def __init__(self):
        self.db = Database()
        self.inventory = FoodInventory()
        self.sensor = SensorSimulator()
        self.predictor = FreshnessPredictor()
        self.detector = SpoilageDetector()
        self.meal_planner = MealPlanner()
        self.spoilage_sim = FoodSpoilageSimulator()
        
        self.running = True
    
    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self, title: str):
        print("\n" + Colors.HEADER + "=" * 60)
        print(f"  {title}")
        print("=" * 60 + Colors.RESET)
    
    def print_menu(self, options: list):
        for i, option in enumerate(options, 1):
            print(f"  [{i}] {option}")
        print()
    
    def get_input(self, prompt: str) -> str:
        return input(f"  {prompt}: ").strip()
    
    def get_choice(self, max_choice: int) -> int:
        try:
            choice = int(input("  Enter choice: "))
            if 1 <= choice <= max_choice:
                return choice
        except ValueError:
            pass
        return -1
    
    def run(self):
        """Main application loop"""
        self.clear_screen()
        
        print(Colors.HEADER + """
   ╔═══════════════════════════════════════════════════════════╗
   ║        AI REFRIGERATOR - FOOD EXPIRY & MEAL PLANNER       ║
   ║                                                           ║
   ║  Smart Food Management with AI Freshness Prediction        ║
   ╚═══════════════════════════════════════════════════════════╝
        """ + Colors.RESET)
        
        print(Colors.SUCCESS + "\n  System initialized successfully!\n")
        
        while self.running:
            self.main_menu()
    
    def main_menu(self):
        """Display main menu"""
        self.print_header("MAIN MENU")
        
        print(f"  {Colors.INFO}Current Date:{Colors.RESET} {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        stats = self.db.get_statistics()
        print(f"  {Colors.INFO}Items in Fridge:{Colors.RESET} {stats['total_items']}")
        print(f"  {Colors.INFO}Unread Alerts:{Colors.RESET} {stats['unread_alerts']}")
        
        print()
        self.print_menu([
            "View Dashboard",
            "Food Inventory Management",
            "Sensor Readings (Simulated)",
            "Freshness Prediction",
            "Meal Planner",
            "Reports & Statistics",
            "Settings",
            "Exit"
        ])
        
        choice = self.get_choice(8)
        
        if choice == 1:
            self.dashboard()
        elif choice == 2:
            self.food_management()
        elif choice == 3:
            self.sensor_readings()
        elif choice == 4:
            self.freshness_prediction()
        elif choice == 5:
            self.meal_menu()
        elif choice == 6:
            self.reports()
        elif choice == 7:
            self.settings()
        elif choice == 8:
            self.exit_app()
    
    def dashboard(self):
        """Display main dashboard"""
        self.print_header("DASHBOARD")
        
        stats = self.db.get_statistics()
        
        print(f"\n  {Colors.INFO}QUICK STATS{Colors.RESET}")
        print(f"  {'─' * 40}")
        print(f"  Total Items:        {stats['total_items']}")
        print(f"  Fresh:              {Colors.SUCCESS}{stats['total_items'] - stats['expired_items'] - stats['expiring_soon']}{Colors.RESET}")
        print(f"  Expiring Soon (3d): {Colors.WARNING}{stats['expiring_soon']}{Colors.RESET}")
        print(f"  Expired:            {Colors.ERROR}{stats['expired_items']}{Colors.RESET}")
        print(f"  Avg Temperature:    {stats['avg_temperature']:.1f}°C")
        
        print(f"\n  {Colors.INFO}EXPIRING SOON (3 DAYS){Colors.RESET}")
        print(f"  {'─' * 40}")
        expiring = self.db.get_expiring_foods(3)
        if expiring:
            for item in expiring[:5]:
                days = (datetime.strptime(item['expiry_date'], "%Y-%m-%d") - datetime.now()).days
                print(f"  - {item['name']}: {days} day(s) left")
        else:
            print("  No items expiring soon!")
        
        print(f"\n  {Colors.INFO}UNREAD ALERTS{Colors.RESET}")
        print(f"  {'─' * 40}")
        alerts = self.db.get_alerts(unread_only=True)
        if alerts:
            for alert in alerts[:3]:
                priority_color = (Colors.ERROR if alert['priority'] == 'high' 
                               else Colors.WARNING)
                print(f"  {priority_color}[{alert['priority'].upper()}]{Colors.RESET} {alert['title']}")
        else:
            print("  No unread alerts!")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def food_management(self):
        """Food inventory management menu"""
        while True:
            self.print_header("FOOD INVENTORY MANAGEMENT")
            
            print(f"  {Colors.INFO}Total Items:{Colors.RESET} {len(self.db.get_all_food_items())}")
            print()
            
            self.print_menu([
                "Add New Food Item",
                "View All Items",
                "View Expiring Items",
                "View Expired Items",
                "Search Food Item",
                "Update Item",
                "Remove Item (Consumed/Wasted)",
                "Shopping List",
                "Back to Main Menu"
            ])
            
            choice = self.get_choice(9)
            
            if choice == 1:
                self.add_food_item()
            elif choice == 2:
                self.view_all_items()
            elif choice == 3:
                self.view_expiring()
            elif choice == 4:
                self.view_expired()
            elif choice == 5:
                self.search_food()
            elif choice == 6:
                self.update_item()
            elif choice == 7:
                self.remove_item()
            elif choice == 8:
                self.shopping_list()
            elif choice == 9:
                break
    
    def add_food_item(self):
        """Add a new food item"""
        self.print_header("ADD NEW FOOD ITEM")
        
        name = self.get_input("Food Name")
        if not name:
            print(f"  {Colors.ERROR}Name is required!{Colors.RESET}")
            return
        
        print("\n  Categories:")
        categories = ["Dairy", "Meat", "Vegetables", "Fruits", "Beverages", 
                     "Grains", "Snacks", "Condiments", "Frozen", "Other"]
        for i, cat in enumerate(categories, 1):
            print(f"    {i}. {cat}")
        
        cat_choice = self.get_input("Category (number)")
        try:
            cat_idx = int(cat_choice) - 1
            category = categories[cat_idx] if 0 <= cat_idx < len(categories) else "Other"
        except:
            category = "Other"
        
        quantity = self.get_input("Quantity")
        try:
            quantity = float(quantity) if quantity else 1
        except:
            quantity = 1
        
        unit = self.get_input("Unit (pieces, kg, liters, etc.)")
        if not unit:
            unit = "pieces"
        
        expiry_days = self.get_input("Days until expiry (or date YYYY-MM-DD)")
        
        purchase_date = datetime.now().strftime("%Y-%m-%d")
        
        if expiry_days:
            try:
                if '-' in expiry_days:
                    expiry_date = expiry_days
                else:
                    expiry_date = (datetime.now() + timedelta(days=int(expiry_days))).strftime("%Y-%m-%d")
            except:
                expiry_date = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
        else:
            expiry_date = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
        
        notes = self.get_input("Notes (optional)")
        
        food_id = self.db.add_food_item(
            name=name,
            category=category,
            quantity=quantity,
            unit=unit,
            purchase_date=purchase_date,
            expiry_date=expiry_date,
            notes=notes
        )
        
        print(f"\n  {Colors.SUCCESS}Food item added successfully! (ID: {food_id}){Colors.RESET}")
        
        self.db.add_alert(
            alert_type="info",
            title=f"New item added: {name}",
            message=f"{quantity} {unit} of {name} added to inventory",
            priority="low"
        )
    
    def view_all_items(self):
        """View all food items"""
        self.print_header("ALL FOOD ITEMS")
        
        items = self.db.get_all_food_items()
        
        if not items:
            print(f"\n  {Colors.WARNING}No items in inventory!{Colors.RESET}")
            return
        
        print(f"\n  {Colors.INFO}{'ID':<4} {'Name':<20} {'Category':<12} {'Qty':<8} {'Expires':<12} {'Status':<15}{Colors.RESET}")
        print(f"  {'─' * 80}")
        
        for item in items:
            expiry = item['expiry_date']
            status = item['status']
            
            status_color = (Colors.SUCCESS if status == 'fresh' 
                          else Colors.WARNING if status == 'expiring_soon' 
                          else Colors.ERROR)
            
            print(f"  {item['id']:<4} {item['name'][:19]:<20} {item['category']:<12} "
                  f"{item['quantity']} {item['unit']:<5} {expiry:<12} "
                  f"{status_color}{status:<15}{Colors.RESET}")
        
        print(f"\n  Total: {len(items)} items")
    
    def view_expiring(self):
        """View items expiring soon"""
        self.print_header("EXPIRING SOON (3 DAYS)")
        
        items = self.db.get_expiring_foods(3)
        
        if not items:
            print(f"\n  {Colors.SUCCESS}No items expiring soon!{Colors.RESET}")
            return
        
        print(f"\n  {Colors.WARNING}Items that will expire within 3 days:{Colors.RESET}\n")
        
        for item in items:
            days = (datetime.strptime(item['expiry_date'], "%Y-%m-%d") - datetime.now()).days
            print(f"  {Colors.ERROR}!{Colors.RESET} {item['name']} - {days} day(s) left")
            print(f"      Quantity: {item['quantity']} {item['unit']}")
            print()
    
    def view_expired(self):
        """View expired items"""
        self.print_header("EXPIRED ITEMS")
        
        items = self.db.get_expired_foods()
        
        if not items:
            print(f"\n  {Colors.SUCCESS}No expired items!{Colors.RESET}")
            return
        
        print(f"\n  {Colors.ERROR}Expired items (discard recommended):{Colors.RESET}\n")
        
        for item in items:
            days = (datetime.now() - datetime.strptime(item['expiry_date'], "%Y-%m-%d")).days
            print(f"  {Colors.ERROR}X{Colors.RESET} {item['name']} - {days} day(s) ago")
            print(f"      Quantity: {item['quantity']} {item['unit']}")
            print()
    
    def search_food(self):
        """Search for a food item"""
        self.print_header("SEARCH FOOD ITEM")
        
        query = self.get_input("Enter name or roll number to search")
        if not query:
            return
        
        items = [item for item in self.db.get_all_food_items() 
                if query.lower() in item['name'].lower()]
        
        if items:
            print(f"\n  {Colors.SUCCESS}Found {len(items)} item(s):{Colors.RESET}\n")
            for item in items:
                print(f"  {item['name']} ({item['category']})")
                print(f"  Qty: {item['quantity']} {item['unit']}")
                print(f"  Expires: {item['expiry_date']} - {item['status']}")
                print()
        else:
            print(f"\n  {Colors.WARNING}No items found!{Colors.RESET}")
    
    def update_item(self):
        """Update a food item"""
        self.print_header("UPDATE FOOD ITEM")
        
        item_id = self.get_input("Enter item ID to update")
        try:
            item_id = int(item_id)
        except:
            print(f"  {Colors.ERROR}Invalid ID!{Colors.RESET}")
            return
        
        item = self.db.get_food_item(item_id)
        if not item:
            print(f"  {Colors.ERROR}Item not found!{Colors.RESET}")
            return
        
        print(f"\n  Current: {item['name']}")
        new_name = self.get_input("New name (or Enter to keep)")
        
        new_qty = self.get_input("New quantity (or Enter to keep)")
        try:
            new_qty = float(new_qty) if new_qty else item['quantity']
        except:
            new_qty = item['quantity']
        
        updates = {}
        if new_name:
            updates['name'] = new_name
        updates['quantity'] = new_qty
        
        self.db.update_food_item(item_id, **updates)
        print(f"\n  {Colors.SUCCESS}Item updated!{Colors.RESET}")
    
    def remove_item(self):
        """Remove a food item"""
        self.print_header("REMOVE FOOD ITEM")
        
        item_id = self.get_input("Enter item ID to remove")
        try:
            item_id = int(item_id)
        except:
            print(f"  {Colors.ERROR}Invalid ID!{Colors.RESET}")
            return
        
        item = self.db.get_food_item(item_id)
        if not item:
            print(f"  {Colors.ERROR}Item not found!{Colors.RESET}")
            return
        
        print(f"\n  Item: {item['name']} ({item['quantity']} {item['unit']})")
        reason = self.get_input("Reason (consumed/wasted):")
        
        self.db.remove_item(item_id, reason)
        print(f"\n  {Colors.SUCCESS}Item removed!{Colors.RESET}")
    
    def shopping_list(self):
        """Generate shopping list"""
        self.print_header("SHOPPING LIST")
        
        shopping = self.inventory.get_shopping_list()
        
        if not shopping:
            print(f"\n  {Colors.WARNING}No items needed!{Colors.RESET}")
            return
        
        print(f"\n  {Colors.INFO}Items to buy:{Colors.RESET}\n")
        for category, items in shopping.items():
            print(f"  {category.title()}:")
            for item in items:
                print(f"    - {item['name']} (expires in {item['expires_in']} days)")
        print()
    
    def sensor_readings(self):
        """Display simulated sensor readings"""
        self.print_header("SENSOR READINGS (SIMULATED)")
        
        print(f"\n  {Colors.INFO}Taking sensor readings...{Colors.RESET}\n")
        
        readings = self.sensor.get_all_readings()
        
        print(f"  Temperature:    {Colors.WARNING}{readings['temperature']:.1f}°C{Colors.RESET}")
        print(f"  Humidity:      {readings['humidity']:.1f}%")
        print(f"  Gas Level:     {readings['gas_level']:.1f} ppm")
        print(f"  Door Status:   {readings['door_status']}")
        print(f"  Timestamp:     {readings['timestamp']}")
        
        self.db.add_sensor_reading(
            temperature=readings['temperature'],
            humidity=readings['humidity'],
            gas_level=readings['gas_level'],
            weight=0
        )
        
        if readings['gas_level'] > 100:
            print(f"\n  {Colors.WARNING}⚠️ Elevated gas levels detected!{Colors.RESET}")
            self.db.add_alert(
                alert_type="warning",
                title="Elevated Gas Levels",
                message=f"Gas level: {readings['gas_level']:.1f} ppm",
                priority="medium"
            )
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def freshness_prediction(self):
        """Freshness prediction menu"""
        while True:
            self.print_header("FRESHNESS PREDICTION")
            
            self.print_menu([
                "Predict All Items",
                "Predict Single Item",
                "View Prediction History",
                "Back to Main Menu"
            ])
            
            choice = self.get_choice(4)
            
            if choice == 1:
                self.predict_all()
            elif choice == 2:
                self.predict_single()
            elif choice == 3:
                self.prediction_history()
            elif choice == 4:
                break
    
    def predict_all(self):
        """Predict freshness for all items"""
        self.print_header("FRESHNESS PREDICTIONS")
        
        items = self.db.get_all_food_items()
        readings = self.sensor.get_all_readings()
        
        sensor_data = {
            'temperature': readings['temperature'],
            'humidity': readings['humidity'],
            'gas_level': readings['gas_level']
        }
        
        print(f"\n  {Colors.INFO}Predictions based on current conditions:{Colors.RESET}")
        print(f"  Temp: {sensor_data['temperature']:.1f}°C, "
              f"Humidity: {sensor_data['humidity']:.1f}%, "
              f"Gas: {sensor_data['gas_level']:.1f} ppm\n")
        
        print(f"  {'Name':<20} {'Freshness':<12} {'Status':<15} {'Days Left':<10}")
        print(f"  {'─' * 60}")
        
        for item in items:
            analysis = self.predictor.get_freshness_analysis(item, sensor_data)
            
            status_color = (Colors.SUCCESS if analysis.status == 'fresh'
                          else Colors.WARNING if analysis.status == 'expiring_soon'
                          else Colors.ERROR)
            
            days_text = f"{analysis.days_until_expiry}" if analysis.days_until_expiry > 0 else "EXPIRED"
            
            print(f"  {item['name'][:19]:<20} "
                  f"{Colors.INFO}{analysis.freshness_score:.0f}%{Colors.RESET:<12} "
                  f"{status_color}{analysis.status:<15}{Colors.RESET} "
                  f"{days_text:<10}")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def predict_single(self):
        """Predict freshness for single item"""
        self.print_header("PREDICT SINGLE ITEM")
        
        item_id = self.get_input("Enter item ID")
        try:
            item_id = int(item_id)
        except:
            print(f"  {Colors.ERROR}Invalid ID!{Colors.RESET}")
            return
        
        item = self.db.get_food_item(item_id)
        if not item:
            print(f"  {Colors.ERROR}Item not found!{Colors.RESET}")
            return
        
        readings = self.sensor.get_all_readings()
        sensor_data = {
            'temperature': readings['temperature'],
            'humidity': readings['humidity'],
            'gas_level': readings['gas_level']
        }
        
        analysis = self.predictor.get_freshness_analysis(item, sensor_data)
        
        print(f"\n  {Colors.INFO}Freshness Analysis for {item['name']}:{Colors.RESET}")
        print(f"  {'─' * 40}")
        print(f"  Freshness Score:  {analysis.freshness_score:.1f}%")
        print(f"  Status:           {analysis.status}")
        print(f"  Days Until Expiry: {analysis.days_until_expiry}")
        print(f"  Confidence:       {analysis.confidence:.0%}")
        
        print(f"\n  {Colors.INFO}Recommendations:{Colors.RESET}")
        for rec in analysis.recommendations:
            print(f"    {rec}")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def prediction_history(self):
        """View prediction history"""
        self.print_header("PREDICTION HISTORY")
        
        history = self.db.get_sensor_history(24)
        
        if not history:
            print(f"\n  {Colors.WARNING}No sensor history available!{Colors.RESET}")
        else:
            print(f"\n  Last {len(history)} readings:\n")
            for reading in history[-10:]:
                print(f"  {reading['timestamp'][:19]} | "
                      f"T: {reading['temperature']:.1f}°C | "
                      f"H: {reading['humidity']:.1f}% | "
                      f"G: {reading['gas_level']:.0f}")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def meal_menu(self):
        """Meal planning menu"""
        while True:
            self.print_header("MEAL PLANNER")
            
            self.print_menu([
                "View Today's Meals",
                "View Weekly Plan",
                "Add Meal Plan",
                "Suggest Meals (Based on Inventory)",
                "Generate Weekly Plan",
                "Back to Main Menu"
            ])
            
            choice = self.get_choice(6)
            
            if choice == 1:
                self.view_today_meals()
            elif choice == 2:
                self.view_weekly_plan()
            elif choice == 3:
                self.add_meal()
            elif choice == 4:
                self.suggest_meals()
            elif choice == 5:
                self.generate_weekly_plan()
            elif choice == 6:
                break
    
    def view_today_meals(self):
        """View today's meals"""
        self.print_header("TODAY'S MEALS")
        
        today = datetime.now().strftime("%Y-%m-%d")
        daily = self.meal_planner.get_daily_plan(today)
        
        for meal_type, plan in daily.items():
            print(f"\n  {meal_type.upper()}:")
            if plan:
                print(f"    {plan['name']}")
                print(f"    Calories: {plan.get('calories', 'N/A')}")
                print(f"    Prep Time: {plan.get('prep_time', 'N/A')} min")
            else:
                print(f"    {Colors.DIM}Not planned{Colors.RESET}")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def view_weekly_plan(self):
        """View weekly meal plan"""
        self.print_header("WEEKLY MEAL PLAN")
        
        start_date = datetime.now()
        week_plan = self.meal_planner.get_weekly_plan(start_date)
        
        for date_str, daily in week_plan.items():
            date_obj = datetime.strptime(date_str, "%Y-%m-%d")
            day_name = date_obj.strftime("%A")
            
            print(f"\n  {Colors.INFO}{date_str} ({day_name}){Colors.RESET}")
            print(f"  {'─' * 40}")
            
            for meal_type, plan in daily.items():
                if plan:
                    print(f"    {meal_type}: {plan['name']}")
                else:
                    print(f"    {meal_type}: {Colors.DIM}--{Colors.RESET}")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def add_meal(self):
        """Add a new meal plan"""
        self.print_header("ADD MEAL PLAN")
        
        name = self.get_input("Recipe Name")
        if not name:
            print(f"  {Colors.ERROR}Name is required!{Colors.RESET}")
            return
        
        description = self.get_input("Description")
        
        print("\n  Meal Types:")
        print("    1. Breakfast")
        print("    2. Lunch")
        print("    3. Dinner")
        print("    4. Snack")
        meal_choice = self.get_input("Meal type (number)")
        meal_types = ['breakfast', 'lunch', 'dinner', 'snack']
        try:
            meal_type = meal_types[int(meal_choice) - 1]
        except:
            meal_type = 'lunch'
        
        date = self.get_input("Date (YYYY-MM-DD, Enter for today)")
        if not date:
            date = datetime.now().strftime("%Y-%m-%d")
        
        ingredients = self.get_input("Ingredients (comma-separated)")
        instructions = self.get_input("Instructions")
        
        calories = self.get_input("Calories")
        try:
            calories = int(calories) if calories else 0
        except:
            calories = 0
        
        prep_time = self.get_input("Prep time (minutes)")
        try:
            prep_time = int(prep_time) if prep_time else 15
        except:
            prep_time = 15
        
        plan_id = self.meal_planner.add_meal_plan(
            name=name,
            description=description,
            date=date,
            meal_type=meal_type,
            ingredients=ingredients,
            instructions=instructions,
            calories=calories,
            prep_time=prep_time
        )
        
        print(f"\n  {Colors.SUCCESS}Meal plan added! (ID: {plan_id}){Colors.RESET}")
    
    def suggest_meals(self):
        """Suggest meals based on inventory"""
        self.print_header("SUGGESTED MEALS")
        
        items = self.inventory.get_all_items()
        available = [item['name'] for item in items]
        
        suggestions = self.meal_planner.suggest_meals_for_inventory(available)
        
        if not suggestions:
            print(f"\n  {Colors.WARNING}No suggestions available!{Colors.RESET}")
            return
        
        print(f"\n  {Colors.INFO}Based on your inventory:{Colors.RESET}\n")
        
        for suggestion in suggestions[:5]:
            print(f"  {Colors.SUCCESS}{suggestion['recipe']}{Colors.RESET}")
            print(f"    Match: {suggestion['match_percentage']}%")
            print(f"    Calories: {suggestion['calories']}")
            print(f"    Time: {suggestion['prep_time']} min")
            if suggestion['missing_ingredients']:
                print(f"    Missing: {', '.join(suggestion['missing_ingredients'][:3])}")
            print()
        
        input(f"  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def generate_weekly_plan(self):
        """Generate weekly meal plan"""
        self.print_header("GENERATE WEEKLY PLAN")
        
        print(f"\n  {Colors.INFO}Generating meal plan for next 7 days...{Colors.RESET}\n")
        
        generated = self.meal_planner.generate_weekly_plan()
        
        print(f"  {Colors.SUCCESS}Generated {len(generated)} meal plans!{Colors.RESET}")
        print("\n  Preview:")
        
        for plan in generated[:6]:
            print(f"    {plan['date']} ({plan['meal_type']}): {plan['recipe'].name}")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def reports(self):
        """Reports and statistics"""
        while True:
            self.print_header("REPORTS & STATISTICS")
            
            self.print_menu([
                "Inventory Summary",
                "Consumption Report",
                "Waste Report",
                "Export Report",
                "Back to Main Menu"
            ])
            
            choice = self.get_choice(5)
            
            if choice == 1:
                self.inventory_summary()
            elif choice == 2:
                self.consumption_report()
            elif choice == 3:
                self.waste_report()
            elif choice == 4:
                self.export_report()
            elif choice == 5:
                break
    
    def inventory_summary(self):
        """Display inventory summary"""
        self.print_header("INVENTORY SUMMARY")
        
        summary = self.inventory.get_inventory_summary()
        
        print(f"\n  Total Items:     {summary['total_items']}")
        print(f"  Fresh:           {summary['fresh_count']}")
        print(f"  Expiring:        {summary['expiring_count']}")
        print(f"  Expired:         {summary['expired_count']}")
        print(f"  Avg Freshness:   {summary['avg_freshness']}%")
        
        print(f"\n  {Colors.INFO}By Category:{Colors.RESET}")
        for category, count in summary['by_category'].items():
            print(f"    {category}: {count}")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def consumption_report(self):
        """Consumption report"""
        self.print_header("CONSUMPTION REPORT")
        
        items = self.db.get_all_food_items()
        consumed = [item for item in items if item['status'] == 'consumed']
        
        print(f"\n  Total Consumed: {len(consumed)} items")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def waste_report(self):
        """Waste report"""
        self.print_header("WASTE REPORT")
        
        items = self.db.get_all_food_items()
        wasted = [item for item in items if item['status'] == 'wasted']
        
        print(f"\n  Total Wasted: {len(wasted)} items")
        
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def export_report(self):
        """Export report to file"""
        self.print_header("EXPORT REPORT")
        
        filename = self.get_input("Enter filename")
        if not filename:
            filename = f"report_{datetime.now().strftime('%Y%m%d')}.txt"
        
        filepath = f"reports/{filename}"
        
        with open(filepath, 'w') as f:
            f.write("AI REFRIGERATOR - FOOD REPORT\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
            f.write("=" * 50 + "\n\n")
            
            summary = self.inventory.get_inventory_summary()
            f.write(f"Total Items: {summary['total_items']}\n")
            f.write(f"Fresh: {summary['fresh_count']}\n")
            f.write(f"Expiring: {summary['expiring_count']}\n")
            f.write(f"Expired: {summary['expired_count']}\n")
        
        print(f"\n  {Colors.SUCCESS}Report exported to {filepath}{Colors.RESET}")
        input(f"\n  {Colors.DIM}Press Enter to continue...{Colors.RESET}")
    
    def settings(self):
        """Settings menu"""
        while True:
            self.print_header("SETTINGS")
            
            print(f"  Temperature Range: {self.db.get_setting('temp_min')}°C - {self.db.get_setting('temp_max')}°C")
            print(f"  Humidity Range: {self.db.get_setting('humidity_min')}%-{self.db.get_setting('humidity_max')}%")
            print(f"  Update Interval: {self.db.get_setting('update_interval')}s")
            print(f"  Alert Enabled: {self.db.get_setting('alert_enabled')}")
            print()
            
            self.print_menu([
                "Update Settings",
                "Clear All Data",
                "Back to Main Menu"
            ])
            
            choice = self.get_choice(3)
            
            if choice == 1:
                self.update_settings()
            elif choice == 2:
                self.clear_data()
            elif choice == 3:
                break
    
    def update_settings(self):
        """Update settings"""
        print("\n  Enter new values (or press Enter to keep current):")
        
        temp_min = self.get_input(f"Min Temp (current: {self.db.get_setting('temp_min')})")
        if temp_min:
            self.db.update_setting('temp_min', temp_min)
        
        temp_max = self.get_input(f"Max Temp (current: {self.db.get_setting('temp_max')})")
        if temp_max:
            self.db.update_setting('temp_max', temp_max)
        
        print(f"\n  {Colors.SUCCESS}Settings updated!{Colors.RESET}")
    
    def clear_data(self):
        """Clear all data"""
        confirm = self.get_input("Are you sure? Type 'yes': ")
        if confirm.lower() == 'yes':
            print(f"\n  {Colors.WARNING}Data cleared!{Colors.RESET}")
    
    def exit_app(self):
        """Exit the application"""
        print(f"\n  {Colors.INFO}Thank you for using AI Refrigerator System!{Colors.RESET}")
        print(f"  {Colors.INFO}Goodbye!{Colors.RESET}\n")
        self.running = False


def main():
    parser = argparse.ArgumentParser(description="AI Refrigerator System")
    parser.add_argument('--demo', action='store_true', help='Run in demo mode')
    parser.add_argument('--web', action='store_true', help='Start web dashboard')
    
    args = parser.parse_args()
    
    if args.web:
        print("Starting web dashboard...")
        os.system('python src/web_dashboard.py')
    else:
        app = CLIApp()
        app.run()


if __name__ == "__main__":
    main()
