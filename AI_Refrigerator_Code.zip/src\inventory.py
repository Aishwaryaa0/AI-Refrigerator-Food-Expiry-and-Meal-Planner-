"""
Food Inventory Management Module
Handles food tracking, expiry management, and inventory operations
"""

import sqlite3
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class FoodStatus(Enum):
    FRESH = "fresh"
    EXPIRING_SOON = "expiring_soon"
    EXPIRED = "expired"
    CONSUMED = "consumed"
    WASTED = "wasted"


class FoodCategory(Enum):
    DAIRY = "Dairy"
    MEAT = "Meat"
    VEGETABLES = "Vegetables"
    FRUITS = "Fruits"
    BEVERAGES = "Beverages"
    GRAINS = "Grains"
    SNACKS = "Snacks"
    CONDIMENTS = "Condiments"
    FROZEN = "Frozen"
    OTHER = "Other"


@dataclass
class FoodItem:
    id: int
    name: str
    category: str
    quantity: float
    unit: str
    purchase_date: datetime
    expiry_date: datetime
    freshness_score: float
    status: str
    notes: str = ""
    
    @property
    def days_until_expiry(self) -> int:
        return (self.expiry_date - datetime.now()).days
    
    @property
    def is_expired(self) -> bool:
        return self.expiry_date < datetime.now()
    
    @property
    def is_expiring_soon(self) -> bool:
        days = self.days_until_expiry
        return 0 <= days <= 3
    
    @property
    def days_since_purchase(self) -> int:
        return (datetime.now() - self.purchase_date).days
    
    @property
    def expected_shelf_life(self) -> int:
        return (self.expiry_date - self.purchase_date).days


class FoodInventory:
    """Main class for food inventory management"""
    
    COMMON_FOODS = {
        "Milk": {"category": "Dairy", "shelf_life": 7, "unit": "liters"},
        "Eggs": {"category": "Dairy", "shelf_life": 21, "unit": "pieces"},
        "Chicken": {"category": "Meat", "shelf_life": 3, "unit": "kg"},
        "Beef": {"category": "Meat", "shelf_life": 5, "unit": "kg"},
        "Fish": {"category": "Seafood", "shelf_life": 2, "unit": "kg"},
        "Tomatoes": {"category": "Vegetables", "shelf_life": 7, "unit": "pieces"},
        "Lettuce": {"category": "Vegetables", "shelf_life": 5, "unit": "heads"},
        "Apples": {"category": "Fruits", "shelf_life": 14, "unit": "pieces"},
        "Bananas": {"category": "Fruits", "shelf_life": 5, "unit": "pieces"},
        "Orange Juice": {"category": "Beverages", "shelf_life": 7, "unit": "liters"},
        "Yogurt": {"category": "Dairy", "shelf_life": 14, "unit": "cups"},
        "Cheese": {"category": "Dairy", "shelf_life": 30, "unit": "kg"},
        "Butter": {"category": "Dairy", "shelf_life": 90, "unit": "kg"},
        "Bread": {"category": "Bakery", "shelf_life": 5, "unit": "loaves"},
        "Rice": {"category": "Grains", "shelf_life": 180, "unit": "kg"},
        "Pasta": {"category": "Grains", "shelf_life": 365, "unit": "kg"},
        "Ice Cream": {"category": "Frozen", "shelf_life": 60, "unit": "liters"},
        "Frozen Pizza": {"category": "Frozen", "shelf_life": 90, "unit": "pieces"},
        "Chicken Breast": {"category": "Meat", "shelf_life": 3, "unit": "kg"},
        "Ground Beef": {"category": "Meat", "shelf_life": 2, "unit": "kg"},
        "Shrimp": {"category": "Seafood", "shelf_life": 2, "unit": "kg"},
        "Carrots": {"category": "Vegetables", "shelf_life": 21, "unit": "pieces"},
        "Potatoes": {"category": "Vegetables", "shelf_life": 30, "unit": "kg"},
        "Onions": {"category": "Vegetables", "shelf_life": 60, "unit": "kg"},
        "Garlic": {"category": "Vegetables", "shelf_life": 30, "unit": "heads"},
        "Bell Peppers": {"category": "Vegetables", "shelf_life": 10, "unit": "pieces"},
        "Mushrooms": {"category": "Vegetables", "shelf_life": 5, "unit": "kg"},
        "Grapes": {"category": "Fruits", "shelf_life": 7, "unit": "kg"},
        "Strawberries": {"category": "Fruits", "shelf_life": 5, "unit": "kg"},
        "Oranges": {"category": "Fruits", "shelf_life": 14, "unit": "pieces"},
        "Lemon": {"category": "Fruits", "shelf_life": 21, "unit": "pieces"},
        "Avocado": {"category": "Fruits", "shelf_life": 3, "unit": "pieces"},
    }
    
    def __init__(self, db_path: str = "data/refrigerator.db"):
        self.db_path = db_path
    
    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def add_item(self, name: str, category: str = None, quantity: float = 1,
                unit: str = "pieces", expiry_days: int = None,
                purchase_date: datetime = None, notes: str = "") -> int:
        
        if purchase_date is None:
            purchase_date = datetime.now()
        
        if category is None:
            category = self._infer_category(name)
        
        if expiry_days is None:
            expiry_days = self._get_default_shelf_life(name)
        
        expiry_date = purchase_date + timedelta(days=expiry_days)
        
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO food_items (name, category, quantity, unit, 
                                  purchase_date, expiry_date, freshness_score, status, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (name, category, quantity, unit, 
              purchase_date.strftime("%Y-%m-%d"),
              expiry_date.strftime("%Y-%m-%d"),
              100.0, "fresh", notes))
        
        item_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return item_id
    
    def remove_item(self, item_id: int, reason: str = "removed"):
        conn = self._get_connection()
        cursor = conn.cursor()
        
        status = "consumed" if reason == "consumed" else "wasted"
        cursor.execute('''
            UPDATE food_items SET status = ? WHERE id = ?
        ''', (status, item_id))
        
        conn.commit()
        conn.close()
    
    def use_item(self, item_id: int, quantity: float = None):
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT quantity, unit FROM food_items WHERE id = ?', (item_id,))
        row = cursor.fetchone()
        
        if row:
            current_qty = row['quantity']
            unit = row['unit']
            
            if quantity is None:
                quantity = current_qty
            
            new_qty = max(0, current_qty - quantity)
            
            if new_qty == 0:
                cursor.execute('UPDATE food_items SET status = ? WHERE id = ?',
                             ("consumed", item_id))
            
            cursor.execute('UPDATE food_items SET quantity = ? WHERE id = ?',
                         (new_qty, item_id))
            
            cursor.execute('''
                INSERT INTO consumption_log (food_item_id, quantity_used, unit, meal_type)
                VALUES (?, ?, ?, ?)
            ''', (item_id, quantity, unit, "unknown"))
        
        conn.commit()
        conn.close()
    
    def get_item(self, item_id: int) -> Optional[Dict]:
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM food_items WHERE id = ?', (item_id,))
        row = cursor.fetchone()
        conn.close()
        
        return dict(row) if row else None
    
    def get_all_items(self, include_consumed: bool = False) -> List[Dict]:
        conn = self._get_connection()
        cursor = conn.cursor()
        
        if include_consumed:
            cursor.execute('SELECT * FROM food_items ORDER BY expiry_date')
        else:
            cursor.execute('''
                SELECT * FROM food_items 
                WHERE status NOT IN ('consumed', 'wasted')
                ORDER BY expiry_date
            ''')
        
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_items_by_category(self, category: str) -> List[Dict]:
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM food_items 
            WHERE category = ? AND status NOT IN ('consumed', 'wasted')
            ORDER BY expiry_date
        ''', (category,))
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_expiring_items(self, days: int = 3) -> List[Dict]:
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cutoff = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
        today = datetime.now().strftime("%Y-%m-%d")
        
        cursor.execute('''
            SELECT * FROM food_items 
            WHERE expiry_date <= ? AND expiry_date >= ? 
            AND status NOT IN ('consumed', 'wasted')
            ORDER BY expiry_date
        ''', (cutoff, today))
        
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_expired_items(self) -> List[Dict]:
        conn = self._get_connection()
        cursor = conn.cursor()
        
        today = datetime.now().strftime("%Y-%m-%d")
        cursor.execute('''
            SELECT * FROM food_items 
            WHERE expiry_date < ? AND status NOT IN ('consumed', 'wasted')
            ORDER BY expiry_date
        ''', (today,))
        
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def update_freshness(self, item_id: int, freshness_score: float):
        conn = self._get_connection()
        cursor = conn.cursor()
        
        status = "expired"
        if freshness_score > 70:
            status = "fresh"
        elif freshness_score > 40:
            status = "expiring_soon"
        
        cursor.execute('''
            UPDATE food_items 
            SET freshness_score = ?, status = ?
            WHERE id = ?
        ''', (freshness_score, status, item_id))
        
        conn.commit()
        conn.close()
    
    def calculate_freshness(self, item_id: int, temperature: float = 4.0,
                          humidity: float = 45.0) -> float:
        item = self.get_item(item_id)
        if not item:
            return 0.0
        
        expiry_date = datetime.strptime(item['expiry_date'], "%Y-%m-%d")
        days_until_expiry = (expiry_date - datetime.now()).days
        
        if days_until_expiry < 0:
            return 0.0
        
        total_shelf_life = (expiry_date - datetime.strptime(
            item['purchase_date'], "%Y-%m-%d")).days
        
        if total_shelf_life <= 0:
            return 100.0
        
        time_score = (days_until_expiry / total_shelf_life) * 70
        
        temp_factor = 1.0
        if temperature > 6:
            temp_factor = 1.0 - ((temperature - 6) * 0.05)
        elif temperature < 2:
            temp_factor = 0.95
        
        humidity_factor = 1.0
        if humidity < 30 or humidity > 60:
            humidity_factor = 0.9
        
        condition_score = 30 * temp_factor * humidity_factor
        
        freshness = min(100, max(0, time_score + condition_score))
        
        return round(freshness, 1)
    
    def get_inventory_summary(self) -> Dict:
        conn = self._get_connection()
        cursor = conn.cursor()
        
        summary = {
            'total_items': 0,
            'fresh_count': 0,
            'expiring_count': 0,
            'expired_count': 0,
            'by_category': {},
            'total_weight': 0,
            'avg_freshness': 0
        }
        
        cursor.execute('''
            SELECT COUNT(*) as count, status FROM food_items 
            WHERE status NOT IN ('consumed', 'wasted')
            GROUP BY status
        ''')
        
        for row in cursor.fetchall():
            summary['total_items'] += row['count']
            if row['status'] == 'fresh':
                summary['fresh_count'] = row['count']
            elif row['status'] == 'expiring_soon':
                summary['expiring_count'] = row['count']
            elif row['status'] == 'expired':
                summary['expired_count'] = row['count']
        
        cursor.execute('''
            SELECT category, COUNT(*) as count FROM food_items 
            WHERE status NOT IN ('consumed', 'wasted')
            GROUP BY category
        ''')
        
        for row in cursor.fetchall():
            summary['by_category'][row['category']] = row['count']
        
        cursor.execute('''
            SELECT AVG(freshness_score) as avg FROM food_items 
            WHERE status NOT IN ('consumed', 'wasted')
        ''')
        row = cursor.fetchone()
        summary['avg_freshness'] = round(row['avg'] or 0, 1)
        
        conn.close()
        return summary
    
    def suggest_consumption_order(self) -> List[Dict]:
        items = self.get_all_items()
        
        priority_items = []
        for item in items:
            days_left = (datetime.strptime(item['expiry_date'], "%Y-%m-%d") - datetime.now()).days
            
            priority = 100 - days_left
            if item['category'] in ['Meat', 'Seafood']:
                priority += 20
            if item['freshness_score'] < 50:
                priority += 15
            
            priority_items.append({
                'id': item['id'],
                'name': item['name'],
                'days_left': days_left,
                'priority': priority,
                'freshness': item['freshness_score'],
                'category': item['category']
            })
        
        priority_items.sort(key=lambda x: x['priority'], reverse=True)
        return priority_items
    
    def _infer_category(self, name: str) -> str:
        name_lower = name.lower()
        
        for food, info in self.COMMON_FOODS.items():
            if food.lower() in name_lower or name_lower in food.lower():
                return info['category']
        
        if any(word in name_lower for word in ['milk', 'cheese', 'yogurt', 'butter', 'cream']):
            return "Dairy"
        elif any(word in name_lower for word in ['chicken', 'beef', 'pork', 'meat', 'fish', 'shrimp']):
            return "Meat"
        elif any(word in name_lower for word in ['tomato', 'lettuce', 'carrot', 'onion', 'potato', 'veg']):
            return "Vegetables"
        elif any(word in name_lower for word in ['apple', 'banana', 'orange', 'fruit', 'grape']):
            return "Fruits"
        
        return "Other"
    
    def _get_default_shelf_life(self, name: str) -> int:
        name_lower = name.lower()
        
        for food, info in self.COMMON_FOODS.items():
            if food.lower() in name_lower or name_lower in food.lower():
                return info['shelf_life']
        
        return 7
    
    def get_shopping_list(self, min_days: int = 5) -> List[Dict]:
        items = self.get_all_items()
        
        shopping_list = {}
        
        for item in items:
            days_left = (datetime.strptime(item['expiry_date'], "%Y-%m-%d") - datetime.now()).days
            
            if days_left < min_days:
                if item['category'] not in shopping_list:
                    shopping_list[item['category']] = []
                
                shopping_list[item['category']].append({
                    'name': item['name'],
                    'current_stock': f"{item['quantity']} {item['unit']}",
                    'expires_in': days_left
                })
        
        return shopping_list


class BarcodeScanner:
    """Simulated barcode scanner for food identification"""
    
    BARCODE_DATABASE = {
        "5901234123457": {"name": "Milk 1L", "category": "Dairy", "shelf_life": 7},
        "4006381333931": {"name": "Orange Juice", "category": "Beverages", "shelf_life": 14},
        "7622210449283": {"name": "Chocolate Bar", "category": "Snacks", "shelf_life": 180},
        "8710398510609": {"name": "Eggs 12pk", "category": "Dairy", "shelf_life": 21},
        "5000159484695": {"name": "Chicken Breast", "category": "Meat", "shelf_life": 3},
    }
    
    def __init__(self):
        self.last_scanned = None
    
    def scan(self, barcode: str = None) -> Optional[Dict]:
        if barcode is None:
            barcode = random.choice(list(self.BARCODE_DATABASE.keys()))
        
        product = self.BARCODE_DATABASE.get(barcode)
        self.last_scanned = barcode
        
        return product
    
    def add_product(self, barcode: str, name: str, category: str, shelf_life: int):
        self.BARCODE_DATABASE[barcode] = {
            "name": name,
            "category": category,
            "shelf_life": shelf_life
        }


import random


if __name__ == "__main__":
    print("Testing Food Inventory Management...")
    
    inventory = FoodInventory()
    
    print("\n=== Current Inventory Summary ===")
    summary = inventory.get_inventory_summary()
    print(f"Total Items: {summary['total_items']}")
    print(f"Fresh: {summary['fresh_count']}")
    print(f"Expiring Soon: {summary['expiring_count']}")
    print(f"Expired: {summary['expired_count']}")
    print(f"Average Freshness: {summary['avg_freshness']}%")
    
    print("\n=== Items Expiring Soon (3 days) ===")
    expiring = inventory.get_expiring_items(3)
    for item in expiring:
        print(f"  - {item['name']}: Expires {item['expiry_date']}")
    
    print("\n=== Suggested Consumption Order ===")
    suggested = inventory.suggest_consumption_order()[:5]
    for item in suggested:
        print(f"  {item['name']}: {item['days_left']} days, Priority: {item['priority']}")
    
    print("\n=== Shopping List ===")
    shopping = inventory.get_shopping_list()
    for category, items in shopping.items():
        print(f"  {category}:")
        for item in items:
            print(f"    - {item['name']} (current: {item['current_stock']})")
