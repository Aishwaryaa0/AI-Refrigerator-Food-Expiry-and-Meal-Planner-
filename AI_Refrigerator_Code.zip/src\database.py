"""
Database Module for AI Refrigerator System
Handles SQLite database operations for food inventory and sensor data
"""

import sqlite3
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import json

class Database:
    def __init__(self, db_path: str = "data/refrigerator.db"):
        self.db_path = db_path
        self.init_database()
    
    def get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS food_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT,
                quantity REAL DEFAULT 1,
                unit TEXT DEFAULT 'pieces',
                purchase_date TEXT,
                expiry_date TEXT,
                added_date TEXT DEFAULT CURRENT_TIMESTAMP,
                freshness_score REAL DEFAULT 100.0,
                status TEXT DEFAULT 'fresh',
                notes TEXT,
                image_url TEXT,
                barcode TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sensor_readings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                temperature REAL,
                humidity REAL,
                gas_level REAL,
                weight REAL,
                pressure REAL,
                food_item_id INTEGER,
                FOREIGN KEY (food_item_id) REFERENCES food_items(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS meal_plans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                date TEXT NOT NULL,
                meal_type TEXT,
                ingredients TEXT,
                instructions TEXT,
                calories INTEGER,
                prep_time INTEGER,
                created_date TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS meal_schedule (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                meal_plan_id INTEGER,
                date TEXT NOT NULL,
                meal_type TEXT,
                status TEXT DEFAULT 'planned',
                FOREIGN KEY (meal_plan_id) REFERENCES meal_plans(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                alert_type TEXT,
                priority TEXT DEFAULT 'medium',
                title TEXT,
                message TEXT,
                food_item_id INTEGER,
                is_read INTEGER DEFAULT 0,
                is_dismissed INTEGER DEFAULT 0,
                FOREIGN KEY (food_item_id) REFERENCES food_items(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS consumption_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                food_item_id INTEGER,
                quantity_used REAL,
                unit TEXT,
                meal_type TEXT,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (food_item_id) REFERENCES food_items(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS waste_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                food_item_id INTEGER,
                quantity_wasted REAL,
                unit TEXT,
                reason TEXT,
                timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (food_item_id) REFERENCES food_items(id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_food_expiry ON food_items(expiry_date)
        ''')
        
        cursor.execute('''
            CREATE INDEX IF NOT EXISTS idx_sensor_timestamp ON sensor_readings(timestamp)
        ''')
        
        self._insert_default_settings(cursor)
        self._insert_sample_data(cursor)
        
        conn.commit()
        conn.close()
    
    def _insert_default_settings(self, cursor):
        default_settings = {
            "temp_min": "2",
            "temp_max": "8",
            "humidity_min": "30",
            "humidity_max": "60",
            "gas_threshold": "100",
            "update_interval": "30",
            "alert_enabled": "true",
            "language": "en",
            "units": "metric"
        }
        for key, value in default_settings.items():
            cursor.execute('''
                INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)
            ''', (key, value))
    
    def _insert_sample_data(self, cursor):
        cursor.execute('SELECT COUNT(*) FROM food_items')
        if cursor.fetchone()[0] > 0:
            return
        
        sample_foods = [
            ("Milk", "Dairy", 1, "liters", "2026-04-10", "2026-04-17", 95.0, "fresh"),
            ("Eggs", "Dairy", 12, "pieces", "2026-04-08", "2026-04-22", 98.0, "fresh"),
            ("Chicken Breast", "Meat", 500, "grams", "2026-04-11", "2026-04-14", 85.0, "fresh"),
            ("Tomatoes", "Vegetables", 6, "pieces", "2026-04-10", "2026-04-16", 90.0, "fresh"),
            ("Orange Juice", "Beverages", 1, "liters", "2026-04-09", "2026-04-15", 75.0, "expiring_soon"),
            ("Yogurt", "Dairy", 2, "cups", "2026-04-07", "2026-04-14", 60.0, "expiring_soon"),
            ("Butter", "Dairy", 200, "grams", "2026-04-05", "2026-04-25", 92.0, "fresh"),
            ("Cheese", "Dairy", 250, "grams", "2026-04-06", "2026-04-20", 88.0, "fresh"),
            ("Bread", "Bakery", 1, "loaf", "2026-04-12", "2026-04-15", 70.0, "expiring_soon"),
            ("Rice", "Grains", 1, "kg", "2026-03-15", "2026-09-15", 100.0, "fresh")
        ]
        
        for food in sample_foods:
            cursor.execute('''
                INSERT INTO food_items (name, category, quantity, unit, purchase_date, 
                                       expiry_date, freshness_score, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', food)
        
        sample_meals = [
            ("Scrambled Eggs", "Quick breakfast with eggs", "2026-04-13", "breakfast", 
             "2 eggs, butter, salt, pepper", "1. Beat eggs\n2. Melt butter\n3. Pour eggs\n4. Stir gently", 250, 10),
            ("Chicken Salad", "Healthy lunch option", "2026-04-13", "lunch",
             "Chicken breast, lettuce, tomatoes, olive oil", "1. Grill chicken\n2. Chop vegetables\n3. Mix together\n4. Add dressing", 400, 25),
            ("Grilled Chicken with Rice", "Simple dinner", "2026-04-13", "dinner",
             "Chicken breast, rice, vegetables", "1. Cook rice\n2. Grill chicken\n3. Steam vegetables\n4. Serve together", 550, 35),
            ("Overnight Oats", "Healthy breakfast prep", "2026-04-14", "breakfast",
             "Oats, milk, yogurt, honey, fruits", "1. Mix oats and milk\n2. Add yogurt\n3. Top with fruits\n4. Refrigerate overnight", 300, 5),
            ("Vegetable Stir Fry", "Quick vegetarian dinner", "2026-04-14", "dinner",
             "Mixed vegetables, soy sauce, garlic, rice", "1. Heat oil\n2. Stir fry vegetables\n3. Add sauce\n4. Serve with rice", 350, 20)
        ]
        
        for meal in sample_meals:
            cursor.execute('''
                INSERT INTO meal_plans (name, description, date, meal_type, 
                                       ingredients, instructions, calories, prep_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', meal)
    
    def add_food_item(self, name: str, category: str, quantity: float, unit: str,
                     purchase_date: str, expiry_date: str, notes: str = "") -> int:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO food_items (name, category, quantity, unit, purchase_date, 
                                   expiry_date, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (name, category, quantity, unit, purchase_date, expiry_date, notes))
        food_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return food_id
    
    def get_all_food_items(self) -> List[Dict]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM food_items ORDER BY expiry_date ASC
        ''')
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_food_item(self, food_id: int) -> Optional[Dict]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM food_items WHERE id = ?', (food_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None
    
    def update_food_item(self, food_id: int, **kwargs):
        allowed_fields = ['name', 'category', 'quantity', 'unit', 'purchase_date',
                          'expiry_date', 'freshness_score', 'status', 'notes']
        updates = {k: v for k, v in kwargs.items() if k in allowed_fields}
        
        if not updates:
            return
        
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [food_id]
        
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(f'UPDATE food_items SET {set_clause} WHERE id = ?', values)
        conn.commit()
        conn.close()
    
    def delete_food_item(self, food_id: int):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM food_items WHERE id = ?', (food_id,))
        conn.commit()
        conn.close()
    
    def get_expiring_foods(self, days: int = 3) -> List[Dict]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cutoff_date = (datetime.now() + timedelta(days=days)).strftime("%Y-%m-%d")
        cursor.execute('''
            SELECT * FROM food_items 
            WHERE expiry_date <= ? AND expiry_date >= date('now')
            ORDER BY expiry_date ASC
        ''', (cutoff_date,))
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_expired_foods(self) -> List[Dict]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM food_items 
            WHERE expiry_date < date('now')
            ORDER BY expiry_date ASC
        ''')
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def add_sensor_reading(self, temperature: float, humidity: float, 
                          gas_level: float, weight: float, 
                          pressure: float = None, food_item_id: int = None):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO sensor_readings (temperature, humidity, gas_level, 
                                        weight, pressure, food_item_id)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (temperature, humidity, gas_level, weight, pressure, food_item_id))
        reading_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return reading_id
    
    def get_latest_sensor_reading(self) -> Optional[Dict]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM sensor_readings 
            ORDER BY timestamp DESC LIMIT 1
        ''')
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None
    
    def get_sensor_history(self, hours: int = 24) -> List[Dict]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM sensor_readings 
            WHERE timestamp >= datetime('now', '-' || ? || ' hours')
            ORDER BY timestamp ASC
        ''', (hours,))
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def add_meal_plan(self, name: str, description: str, date: str, 
                     meal_type: str, ingredients: str, instructions: str,
                     calories: int = 0, prep_time: int = 0) -> int:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO meal_plans (name, description, date, meal_type, 
                                   ingredients, instructions, calories, prep_time)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (name, description, date, meal_type, ingredients, instructions, 
              calories, prep_time))
        plan_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return plan_id
    
    def get_meal_plans(self, date: str = None) -> List[Dict]:
        conn = self.get_connection()
        cursor = conn.cursor()
        if date:
            cursor.execute('''
                SELECT * FROM meal_plans WHERE date = ? ORDER BY meal_type
            ''', (date,))
        else:
            cursor.execute('SELECT * FROM meal_plans ORDER BY date DESC')
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def get_meal_plan(self, plan_id: int) -> Optional[Dict]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM meal_plans WHERE id = ?', (plan_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None
    
    def update_meal_plan(self, plan_id: int, **kwargs):
        allowed_fields = ['name', 'description', 'date', 'meal_type', 
                         'ingredients', 'instructions', 'calories', 'prep_time']
        updates = {k: v for k, v in kwargs.items() if k in allowed_fields}
        
        if not updates:
            return
        
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [plan_id]
        
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute(f'UPDATE meal_plans SET {set_clause} WHERE id = ?', values)
        conn.commit()
        conn.close()
    
    def delete_meal_plan(self, plan_id: int):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM meal_plans WHERE id = ?', (plan_id,))
        conn.commit()
        conn.close()
    
    def add_alert(self, alert_type: str, title: str, message: str,
                 priority: str = "medium", food_item_id: int = None):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO alerts (alert_type, title, message, priority, food_item_id)
            VALUES (?, ?, ?, ?, ?)
        ''', (alert_type, title, message, priority, food_item_id))
        alert_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return alert_id
    
    def get_alerts(self, unread_only: bool = False) -> List[Dict]:
        conn = self.get_connection()
        cursor = conn.cursor()
        if unread_only:
            cursor.execute('''
                SELECT * FROM alerts 
                WHERE is_read = 0 AND is_dismissed = 0
                ORDER BY timestamp DESC
            ''')
        else:
            cursor.execute('''
                SELECT * FROM alerts 
                WHERE is_dismissed = 0
                ORDER BY timestamp DESC
            ''')
        items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return items
    
    def mark_alert_read(self, alert_id: int):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('UPDATE alerts SET is_read = 1 WHERE id = ?', (alert_id,))
        conn.commit()
        conn.close()
    
    def dismiss_alert(self, alert_id: int):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('UPDATE alerts SET is_dismissed = 1 WHERE id = ?', (alert_id,))
        conn.commit()
        conn.close()
    
    def get_setting(self, key: str) -> Optional[str]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT value FROM settings WHERE key = ?', (key,))
        row = cursor.fetchone()
        conn.close()
        return row['value'] if row else None
    
    def update_setting(self, key: str, value: str):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)
        ''', (key, value))
        conn.commit()
        conn.close()
    
    def get_statistics(self) -> Dict:
        conn = self.get_connection()
        cursor = conn.cursor()
        
        stats = {}
        
        cursor.execute('SELECT COUNT(*) as count FROM food_items')
        stats['total_items'] = cursor.fetchone()['count']
        
        cursor.execute('''
            SELECT COUNT(*) as count FROM food_items 
            WHERE expiry_date < date('now')
        ''')
        stats['expired_items'] = cursor.fetchone()['count']
        
        cursor.execute('''
            SELECT COUNT(*) as count FROM food_items 
            WHERE expiry_date >= date('now') 
            AND expiry_date <= date('now', '+3 days')
        ''')
        stats['expiring_soon'] = cursor.fetchone()['count']
        
        cursor.execute('SELECT COUNT(*) as count FROM alerts WHERE is_read = 0')
        stats['unread_alerts'] = cursor.fetchone()['count']
        
        cursor.execute('''
            SELECT AVG(temperature) as avg_temp FROM sensor_readings 
            WHERE timestamp >= datetime('now', '-24 hours')
        ''')
        stats['avg_temperature'] = cursor.fetchone()['avg_temp'] or 0
        
        cursor.execute('''
            SELECT COUNT(*) as count FROM meal_plans 
            WHERE date = date('now')
        ''')
        stats['today_meals'] = cursor.fetchone()['count']
        
        conn.close()
        return stats
    
    def log_consumption(self, food_item_id: int, quantity: float, unit: str, meal_type: str):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO consumption_log (food_item_id, quantity_used, unit, meal_type)
            VALUES (?, ?, ?, ?)
        ''', (food_item_id, quantity, unit, meal_type))
        
        cursor.execute('SELECT quantity FROM food_items WHERE id = ?', (food_item_id,))
        row = cursor.fetchone()
        if row:
            new_qty = max(0, row['quantity'] - quantity)
            cursor.execute('UPDATE food_items SET quantity = ? WHERE id = ?', 
                         (new_qty, food_item_id))
        
        conn.commit()
        conn.close()
    
    def log_waste(self, food_item_id: int, quantity: float, unit: str, reason: str):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO waste_log (food_item_id, quantity_wasted, unit, reason)
            VALUES (?, ?, ?, ?)
        ''', (food_item_id, quantity, unit, reason))
        conn.commit()
        conn.close()
    
    def get_food_categories(self) -> List[str]:
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT DISTINCT category FROM food_items WHERE category IS NOT NULL')
        categories = [row['category'] for row in cursor.fetchall()]
        conn.close()
        return categories


if __name__ == "__main__":
    print("Initializing Database...")
    db = Database()
    print("Database initialized successfully!")
    print(f"Location: {db.db_path}")
    
    stats = db.get_statistics()
    print(f"\nStatistics:")
    print(f"  Total Items: {stats['total_items']}")
    print(f"  Expired: {stats['expired_items']}")
    print(f"  Expiring Soon: {stats['expiring_soon']}")
