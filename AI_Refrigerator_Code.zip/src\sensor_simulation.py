"""
Sensor Simulation Module for AI Refrigerator System
Simulates hardware sensor data for testing without actual hardware
"""

import random
import time
from datetime import datetime
from typing import Dict, List, Tuple, Optional
import json
import os

class SensorSimulator:
    def __init__(self, environment_temp: float = 22.0, 
                 environment_humidity: float = 55.0):
        self.environment_temp = environment_temp
        self.environment_humidity = environment_humidity
        
        self.refrigerator_temp = 4.0
        self.refrigerator_humidity = 45.0
        
        self.door_open_count = 0
        self.last_reading_time = time.time()
        
        self.sensor_noise_level = {
            'temperature': 0.5,
            'humidity': 2.0,
            'gas': 10.0,
            'weight': 5.0
        }
        
        self.gas_baseline = 30.0
        self.gas_spike_threshold = 150.0
        
        self.load_cell_calibration = 1.0
        self.tare_weight = 0.0
        
        self.dht22_available = True
        self.mq135_available = True
        self.hx711_available = True
        self.bme280_available = False
    
    def simulate_dht22(self) -> Tuple[float, float]:
        """Simulate DHT22 temperature and humidity sensor"""
        temp_variation = random.gauss(0, self.sensor_noise_level['temperature'])
        humidity_variation = random.gauss(0, self.sensor_noise_level['humidity'])
        
        temp = self.refrigerator_temp + temp_variation
        humidity = self.refrigerator_humidity + humidity_variation
        
        if self._is_door_open():
            temp += random.uniform(1.0, 3.0)
            humidity += random.uniform(-5.0, 5.0)
        
        temp = max(-40, min(80, temp))
        humidity = max(0, min(100, humidity))
        
        response_time = random.uniform(0.1, 0.5)
        time.sleep(response_time)
        
        return round(temp, 2), round(humidity, 2)
    
    def simulate_bme280(self) -> Dict[str, float]:
        """Simulate BME280 sensor (temperature, humidity, pressure)"""
        temp, humidity = self.simulate_dht22()
        
        pressure_variation = random.gauss(0, 0.5)
        pressure = 1013.25 + pressure_variation
        
        if self._is_door_open():
            pressure += random.uniform(-2.0, 2.0)
        
        return {
            'temperature': temp,
            'humidity': humidity,
            'pressure': round(pressure, 2)
        }
    
    def simulate_mq135(self) -> float:
        """Simulate MQ-135 gas sensor for air quality/alcohol/CO2"""
        base_gas = self.gas_baseline
        
        gas_variation = random.gauss(0, self.sensor_noise_level['gas'])
        gas_level = base_gas + gas_variation
        
        spoilage_factor = self._calculate_spoilage_factor()
        gas_level += spoilage_factor * 50
        
        if self._is_door_open():
            gas_level -= random.uniform(10, 20)
        
        gas_level = max(0, min(1000, gas_level))
        
        return round(gas_level, 2)
    
    def simulate_hx711(self, container_weight: float = 0.0) -> float:
        """Simulate HX711 load cell for weight measurement"""
        variation = random.gauss(0, self.sensor_noise_level['weight'])
        weight = container_weight + self.tare_weight + variation
        
        weight = max(0, weight)
        
        return round(weight, 2)
    
    def simulate_gas_classification(self) -> Dict[str, float]:
        """Simulate gas classification output"""
        gas_level = self.simulate_mq135()
        
        return {
            'co2': gas_level * random.uniform(0.3, 0.5),
            'nh3': gas_level * random.uniform(0.1, 0.2),
            'alcohol': gas_level * random.uniform(0.2, 0.4),
            'toluene': gas_level * random.uniform(0.05, 0.1),
            'acetone': gas_level * random.uniform(0.1, 0.2)
        }
    
    def _is_door_open(self) -> bool:
        """Simulate refrigerator door open/close state"""
        time_since_last = time.time() - self.last_reading_time
        
        if time_since_last < 5:
            return self.door_open_count % 10 == 0
        
        if random.random() < 0.05:
            self.door_open_count += 1
            self.refrigerator_temp += random.uniform(0.5, 1.5)
            self.refrigerator_humidity += random.uniform(-3, 3)
            return True
        
        if self.refrigerator_temp > 4.5:
            self.refrigerator_temp = max(3.5, self.refrigerator_temp - 0.1)
        
        return False
    
    def _calculate_spoilage_factor(self) -> float:
        """Calculate spoilage factor based on time and conditions"""
        time_factor = (time.time() % 86400) / 86400.0
        
        temp_factor = (self.refrigerator_temp - 4.0) / 4.0 if self.refrigerator_temp > 4 else 0
        
        humidity_factor = abs(self.refrigerator_humidity - 45) / 45.0
        
        spoilage = time_factor * 0.3 + temp_factor * 0.4 + humidity_factor * 0.3
        
        return spoilage
    
    def get_all_readings(self) -> Dict:
        """Get all sensor readings at once"""
        dht_data = self.simulate_dht22()
        mq135_data = self.simulate_mq135()
        gas_class = self.simulate_gas_classification()
        
        return {
            'timestamp': datetime.now().isoformat(),
            'temperature': dht_data[0],
            'humidity': dht_data[1],
            'gas_level': mq135_data,
            'gas_classification': gas_class,
            'door_status': 'open' if self._is_door_open() else 'closed',
            'refrigerator_temp': self.refrigerator_temp,
            'refrigerator_humidity': self.refrigerator_humidity
        }
    
    def set_refrigerator_conditions(self, temperature: float, humidity: float):
        """Set target refrigerator conditions"""
        self.refrigerator_temp = max(-5, min(15, temperature))
        self.refrigerator_humidity = max(20, min(80, humidity))
    
    def calibrate_sensors(self, known_weight: float = None):
        """Calibrate sensors with known reference"""
        print("[SIMULATION] Calibrating sensors...")
        
        if known_weight:
            self.load_cell_calibration = known_weight / self.simulate_hx711(known_weight)
            print(f"[SIMULATION] Load cell calibrated with factor: {self.load_cell_calibration:.4f}")
        
        self.gas_baseline = random.uniform(25, 35)
        print(f"[SIMULATION] Gas sensor baseline set to: {self.gas_baseline:.2f}")
        
        self.refrigerator_temp = 4.0
        self.refrigerator_humidity = 45.0
        print("[SIMULATION] Temperature/Humidity baseline calibrated")
        
        print("[SIMULATION] Sensor calibration complete!")
    
    def get_sensor_status(self) -> Dict:
        """Get status of all simulated sensors"""
        return {
            'dht22': {
                'available': self.dht22_available,
                'status': 'active',
                'last_reading': datetime.now().isoformat()
            },
            'mq135': {
                'available': self.mq135_available,
                'status': 'active',
                'baseline': self.gas_baseline
            },
            'hx711': {
                'available': self.hx711_available,
                'status': 'active',
                'calibration_factor': self.load_cell_calibration
            },
            'bme280': {
                'available': self.bme280_available,
                'status': 'unavailable' if not self.bme280_available else 'active'
            }
        }
    
    def simulate_power_consumption(self) -> Dict:
        """Calculate simulated power consumption"""
        base_power = 50
        
        sensor_power = 0
        if self.dht22_available:
            sensor_power += 0.5
        if self.mq135_available:
            sensor_power += 1.5
        if self.hx711_available:
            sensor_power += 1.0
        if self.bme280_available:
            sensor_power += 1.0
        
        compressor_power = 80 if self.refrigerator_temp > 5 else 20
        
        led_power = 5 if self._is_door_open() else 0
        
        total_power = base_power + sensor_power + compressor_power + led_power
        
        return {
            'total_watts': total_power,
            'components': {
                'base': base_power,
                'sensors': sensor_power,
                'compressor': compressor_power,
                'led': led_power
            },
            'estimated_daily_kwh': (total_power * 24) / 1000
        }


class FoodSpoilageSimulator:
    """Simulates food spoilage based on conditions"""
    
    SPOILAGE_MODELS = {
        'meat': {
            'base_temp_max': 4,
            'humidity_range': (30, 70),
            'spoilage_rate': 1.5,
            'indicative_gases': ['ammonia', 'hydrogen_sulfide']
        },
        'dairy': {
            'base_temp_max': 6,
            'humidity_range': (20, 60),
            'spoilage_rate': 1.2,
            'indicative_gases': ['lactic_acid']
        },
        'vegetables': {
            'base_temp_max': 8,
            'humidity_range': (40, 80),
            'spoilage_rate': 0.8,
            'indicative_gases': ['ethylene', 'ethanol']
        },
        'fruits': {
            'base_temp_max': 10,
            'humidity_range': (50, 90),
            'spoilage_rate': 1.0,
            'indicative_gases': ['ethylene']
        },
        'seafood': {
            'base_temp_max': 2,
            'humidity_range': (30, 70),
            'spoilage_rate': 2.0,
            'indicative_gases': ['trimethylamine', 'ammonia']
        }
    }
    
    def __init__(self):
        self.food_items = []
    
    def add_food_item(self, name: str, category: str, 
                     expiry_date: datetime, freshness: float = 100.0):
        self.food_items.append({
            'name': name,
            'category': category,
            'expiry_date': expiry_date,
            'freshness': freshness,
            'last_updated': datetime.now()
        })
    
    def update_freshness(self, food_name: str, temperature: float,
                        humidity: float, gas_levels: Dict[str, float]):
        for item in self.food_items:
            if item['name'].lower() == food_name.lower():
                category = item['category'].lower()
                
                if category in self.SPOILAGE_MODELS:
                    model = self.SPOILAGE_MODELS[category]
                    
                    temp_factor = 1.0
                    if temperature > model['base_temp_max']:
                        temp_factor = 1.0 + ((temperature - model['base_temp_max']) * 0.1)
                    
                    humidity_low, humidity_high = model['humidity_range']
                    humidity_factor = 1.0
                    if humidity < humidity_low:
                        humidity_factor = 1.0 + ((humidity_low - humidity) / humidity_low) * 0.5
                    elif humidity > humidity_high:
                        humidity_factor = 1.0 + ((humidity - humidity_high) / humidity_high) * 0.5
                    
                    gas_factor = 1.0
                    total_gas = sum(gas_levels.values())
                    if total_gas > 100:
                        gas_factor = 1.0 + ((total_gas - 100) / 100) * 0.5
                    
                    days_until_expiry = (item['expiry_date'] - datetime.now()).days
                    time_factor = 1.0
                    if days_until_expiry < 3:
                        time_factor = 1.5
                    
                    spoilage_rate = (model['spoilage_rate'] * 
                                    temp_factor * humidity_factor * 
                                    gas_factor * time_factor * 0.1)
                    
                    item['freshness'] = max(0, item['freshness'] - spoilage_rate)
                    item['last_updated'] = datetime.now()
                    
                    return item['freshness']
        
        return None
    
    def get_freshness_score(self, food_name: str) -> Optional[float]:
        for item in self.food_items:
            if item['name'].lower() == food_name.lower():
                return item['freshness']
        return None
    
    def get_all_freshness(self) -> List[Dict]:
        return self.food_items.copy()


def run_simulation_demo():
    """Run a demonstration of the sensor simulation"""
    print("=" * 60)
    print("AI REFRIGERATOR - SENSOR SIMULATION DEMO")
    print("=" * 60)
    
    sensor = SensorSimulator()
    spoilage = FoodSpoilageSimulator()
    
    print("\n[1] Initializing sensors...")
    sensor.calibrate_sensors()
    
    print("\n[2] Running sensor readings simulation...")
    for i in range(5):
        print(f"\n--- Reading {i+1} ---")
        readings = sensor.get_all_readings()
        
        print(f"  Temperature: {readings['temperature']}°C")
        print(f"  Humidity: {readings['humidity']}%")
        print(f"  Gas Level: {readings['gas_level']} ppm")
        print(f"  Door Status: {readings['door_status']}")
        
        time.sleep(1)
    
    print("\n[3] Testing gas classification...")
    gas_data = sensor.simulate_gas_classification()
    print(f"  CO2: {gas_data['co2']:.2f} ppm")
    print(f"  NH3: {gas_data['nh3']:.2f} ppm")
    print(f"  Alcohol: {gas_data['alcohol']:.2f} ppm")
    
    print("\n[4] Testing weight sensor...")
    weights = [sensor.simulate_hx711(w) for w in [100, 250, 500, 1000]]
    print(f"  Measured weights: {weights}")
    
    print("\n[5] Testing power consumption...")
    power = sensor.simulate_power_consumption()
    print(f"  Total Power: {power['total_watts']}W")
    print(f"  Daily Consumption: {power['estimated_daily_kwh']:.2f} kWh")
    
    print("\n[6] Testing food spoilage simulation...")
    spoilage.add_food_item("Chicken", "meat", 
                           datetime.now() + timedelta(days=2), 95.0)
    spoilage.add_food_item("Milk", "dairy",
                           datetime.now() + timedelta(days=5), 98.0)
    
    for item in spoilage.get_all_freshness():
        print(f"  {item['name']}: {item['freshness']:.1f}%")
    
    print("\n" + "=" * 60)
    print("SIMULATION COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    from datetime import timedelta
    run_simulation_demo()
